import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import Database from "better-sqlite3";
import fs from "fs";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));

// Initialize Database
const dbPath = path.join(process.cwd(), "data");
if (!fs.existsSync(dbPath)) {
  fs.mkdirSync(dbPath);
}
const db = new Database(path.join(dbPath, "game.db"));

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS worlds (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    currentResponse TEXT NOT NULL,
    history TEXT NOT NULL,
    timestamp INTEGER NOT NULL
  )
`);

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

app.get("/api/worlds", (req, res) => {
  try {
    const worlds = db.prepare("SELECT * FROM worlds ORDER BY timestamp DESC").all();
    const parsedWorlds = worlds.map((w: any) => ({
      ...w,
      currentResponse: JSON.parse(w.currentResponse),
      history: JSON.parse(w.history)
    }));
    res.json(parsedWorlds);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch worlds" });
  }
});

app.post("/api/worlds", (req, res) => {
  const { id, name, currentResponse, history, timestamp } = req.body;
  try {
    const stmt = db.prepare(`
      INSERT INTO worlds (id, name, currentResponse, history, timestamp)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        currentResponse = excluded.currentResponse,
        history = excluded.history,
        timestamp = excluded.timestamp
    `);
    stmt.run(id, name, JSON.stringify(currentResponse), JSON.stringify(history), timestamp);
    res.json({ success: true });
  } catch (error) {
    console.error("Save error:", error);
    res.status(500).json({ error: "Failed to save world" });
  }
});

app.delete("/api/worlds/:id", (req, res) => {
  const { id } = req.params;
  try {
    db.prepare("DELETE FROM worlds WHERE id = ?").run(id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete world" });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
