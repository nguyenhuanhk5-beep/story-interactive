import React, { useState } from 'react';
import { Shield, Zap, Package, MapPin, Clock, Users, AlertTriangle, Flag, Activity, Dices, Target, Map, Loader2, BookOpen, ScrollText, ChevronDown, ChevronRight, Coins, Store, HelpCircle } from 'lucide-react';
import { GameState } from '../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';

interface StatusBoardProps {
  state: GameState;
  onGenerateMap?: () => void;
  isGeneratingMap?: boolean;
}

export default function StatusBoard({ state, onGenerateMap, isGeneratingMap }: StatusBoardProps) {
  const [isLorebookOpen, setIsLorebookOpen] = useState(false);
  const [isArcSummaryOpen, setIsArcSummaryOpen] = useState(true);
  const [isLongTermGoalsOpen, setIsLongTermGoalsOpen] = useState(true);
  const [isMcStatusOpen, setIsMcStatusOpen] = useState(true);
  const [isEconomyOpen, setIsEconomyOpen] = useState(true);
  const [isWorldOpen, setIsWorldOpen] = useState(true);
  const [isGlobalContextOpen, setIsGlobalContextOpen] = useState(true);
  const [isDiceRollOpen, setIsDiceRollOpen] = useState(true);
  const [isNpcTrackerOpen, setIsNpcTrackerOpen] = useState(true);
  const [isFactionTrackerOpen, setIsFactionTrackerOpen] = useState(true);
  const [isConsequencesOpen, setIsConsequencesOpen] = useState(true);

  const toggleAll = (open: boolean) => {
    setIsLorebookOpen(open);
    setIsArcSummaryOpen(open);
    setIsLongTermGoalsOpen(open);
    setIsMcStatusOpen(open);
    setIsEconomyOpen(open);
    setIsWorldOpen(open);
    setIsGlobalContextOpen(open);
    setIsDiceRollOpen(open);
    setIsNpcTrackerOpen(open);
    setIsFactionTrackerOpen(open);
    setIsConsequencesOpen(open);
  };

  return (
    <div className="w-80 flex flex-col gap-4 h-full overflow-y-auto pr-2 custom-scrollbar">
      <div className="flex justify-end gap-3 px-1">
        <button onClick={() => toggleAll(false)} className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 hover:text-zinc-300 transition-colors">Thu gọn tất cả</button>
        <button onClick={() => toggleAll(true)} className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 hover:text-zinc-300 transition-colors">Mở rộng tất cả</button>
      </div>
      
      {/* MC Status */}
      <section className="p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
        <button 
          onClick={() => setIsMcStatusOpen(!isMcStatusOpen)}
          className="w-full flex items-center justify-between group"
        >
          <div className="flex items-center gap-2 text-orange-500">
            <Shield className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wider text-xs">Nhân Vật Chính</h3>
          </div>
          {isMcStatusOpen ? <ChevronDown className="w-4 h-4 text-zinc-500 group-hover:text-orange-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-orange-400 transition-colors" />}
        </button>
        <AnimatePresence>
          {isMcStatusOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="space-y-3 mt-4">
                <div className="flex justify-between items-center">
                  <span className="text-zinc-500 text-xs uppercase">HP</span>
                  <span className="text-red-400 font-mono text-sm">
                    {state.MC_Status.HP_Current !== undefined ? `${state.MC_Status.HP_Current}/${state.MC_Status.HP_Max}` : state.MC_Status.HP}
                  </span>
                </div>
                {(state.MC_Status.Resource_Label || state.MC_Status.MP) && (
                  <div className="flex justify-between items-center">
                    <span className="text-zinc-500 text-xs uppercase">{state.MC_Status.Resource_Label || "Linh Lực"}</span>
                    <span className="text-cyan-400 font-mono text-sm">
                      {state.MC_Status.Resource_Current !== undefined ? `${state.MC_Status.Resource_Current}/${state.MC_Status.Resource_Max}` : state.MC_Status.MP}
                    </span>
                  </div>
                )}
                <div className="flex justify-between items-center">
                  <span className="text-zinc-500 text-xs uppercase">Cảnh Giới</span>
                  <span className="text-blue-400 font-mono text-sm">{state.MC_Status.Level}</span>
                </div>
                {state.MC_Status.Skill_Mastery && state.MC_Status.Skill_Mastery.length > 0 && (
                  <div className="pt-2 border-t border-zinc-800">
                    <div className="flex items-center gap-2 mb-2 text-zinc-500">
                      <span className="text-[10px] uppercase">Độ Thành Thạo</span>
                    </div>
                    <div className="flex flex-col gap-2">
                      {state.MC_Status.Skill_Mastery.map((mastery: any, i) => (
                        <div key={i} className="p-2 bg-emerald-500/5 border border-emerald-500/10 rounded-lg">
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-mono text-emerald-400 text-xs font-bold">{mastery.Base_Skill_Name}</span>
                            <span className={`text-[10px] px-1.5 py-0.5 rounded ${mastery.Mastered ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                              {mastery.Mastered ? 'Đã thành thạo' : 'Chưa thành thạo'}
                            </span>
                          </div>
                          <div className="text-[10px] text-zinc-400">
                            Cấp độ: <span className="text-zinc-300">{mastery.Tier}</span>
                          </div>
                          <div className="text-[10px] text-zinc-500 mt-1 flex gap-3">
                            <span>Tiêu hao: {mastery.Normal_Cost_Resource} {state.MC_Status.Resource_Label || "Linh Lực"}</span>
                            {mastery.Normal_Cost_HP > 0 && <span className="text-red-400/80">Tốn {mastery.Normal_Cost_HP} HP</span>}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {state.MC_Status.Skills && state.MC_Status.Skills.length > 0 && (
                  <div className="pt-2 border-t border-zinc-800">
                    <div className="flex items-center gap-2 mb-2 text-zinc-500">
                      <span className="text-[10px] uppercase">Chiêu Thức</span>
                    </div>
                    <div className="flex flex-col gap-2">
                      {state.MC_Status.Skills.map((skill: any, i) => (
                        <div key={i} className="p-2 bg-orange-500/5 border border-orange-500/10 rounded-lg group relative">
                          <div className="font-mono text-orange-400 text-xs font-bold mb-1">{typeof skill === 'string' ? skill : skill.Name}</div>
                          {typeof skill !== 'string' && (
                            <>
                              <div className="text-[10px] text-zinc-400 leading-relaxed mb-1">{skill.Description}</div>
                              <div className="text-[10px] text-emerald-400/80 italic leading-relaxed border-t border-emerald-500/10 pt-1 mt-1">
                                <span className="font-bold text-emerald-500/80">Cách dùng:</span> {skill.Usage_Hint}
                              </div>
                            </>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                <div className="pt-2 border-t border-zinc-800">
                  <div className="flex items-center gap-2 mb-1 text-zinc-500">
                    <Package className="w-3 h-3" />
                    <span className="text-[10px] uppercase">Hành Trang</span>
                  </div>
                  <p className="text-xs text-zinc-300 leading-relaxed">{state.MC_Status.Inventory}</p>
                </div>
                {state.MC_Status.Wealth && (
                  <div className="pt-2 border-t border-zinc-800">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2 text-zinc-500">
                        <Coins className="w-3 h-3 text-yellow-500" />
                        <span className="text-[10px] uppercase text-yellow-500/80">Tài Sản</span>
                      </div>
                      <div className="relative group">
                        <HelpCircle className="w-3 h-3 text-zinc-500 cursor-help hover:text-zinc-300 transition-colors" />
                        <div className="absolute right-0 bottom-full mb-2 w-64 p-3 bg-zinc-800 text-zinc-300 text-[10px] rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 pointer-events-none border border-zinc-700">
                          <div className="font-bold text-yellow-500 mb-1 border-b border-zinc-700 pb-1">Hệ Quy Chiếu Giá Trị</div>
                          <ul className="space-y-1">
                            <li><span className="text-zinc-400">Phàm nhân/Tạp dịch:</span> 1 - 10 Hạ phẩm</li>
                            <li><span className="text-zinc-400">Luyện Khí kỳ:</span> 10 - 500 Hạ phẩm</li>
                            <li><span className="text-zinc-400">Trúc Cơ kỳ:</span> 1,000 - 5,000 Hạ phẩm</li>
                            <li><span className="text-zinc-400">Kết Đan kỳ:</span> Hàng vạn Hạ phẩm</li>
                          </ul>
                          <div className="mt-2 pt-1 border-t border-zinc-700 text-[9px] text-zinc-500 italic">
                            1 Cực phẩm = 100 Thượng phẩm = 10,000 Trung phẩm = 1,000,000 Hạ phẩm
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {state.MC_Status.Wealth.Spirit_Stones !== undefined && (
                        <div className="flex justify-between items-center bg-zinc-800/50 px-2 py-1 rounded">
                          <span className="text-zinc-400">Linh Thạch:</span>
                          <span className="text-yellow-400 font-mono">{state.MC_Status.Wealth.Spirit_Stones}</span>
                        </div>
                      )}
                      {state.MC_Status.Wealth.Merit_Points !== undefined && (
                        <div className="flex justify-between items-center bg-zinc-800/50 px-2 py-1 rounded">
                          <span className="text-zinc-400">Công Huân:</span>
                          <span className="text-blue-400 font-mono">{state.MC_Status.Wealth.Merit_Points}</span>
                        </div>
                      )}
                    </div>
                    {state.MC_Status.Wealth.Salary_Info && (
                      <div className="mt-1 text-[10px] text-zinc-500 italic">
                        Lương: {state.MC_Status.Wealth.Salary_Info}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* Economy & Activities */}
      <section className="p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
        <button 
          onClick={() => setIsEconomyOpen(!isEconomyOpen)}
          className="w-full flex items-center justify-between group"
        >
          <div className="flex items-center gap-2 text-yellow-500">
            <Store className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wider text-xs">Kinh Tế & Hoạt Động</h3>
          </div>
          {isEconomyOpen ? <ChevronDown className="w-4 h-4 text-zinc-500 group-hover:text-yellow-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-yellow-400 transition-colors" />}
        </button>
        <AnimatePresence>
          {isEconomyOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="space-y-4 mt-4">
                {(!state.Available_Missions || state.Available_Missions.length === 0) && (!state.Available_Shop_Items || state.Available_Shop_Items.length === 0) ? (
                  <div className="text-center p-3 bg-zinc-800/30 rounded-lg border border-zinc-800/50">
                    <p className="text-[10px] text-zinc-500 italic mb-2">Không có nhiệm vụ hoặc cửa hàng nào khả dụng tại khu vực này.</p>
                    <p className="text-[9px] text-zinc-400">💡 Gõ vào khung chat: "Có cửa hàng hay nhiệm vụ nào quanh đây không?" để tìm kiếm.</p>
                  </div>
                ) : (
                  <>
                    {state.Available_Missions && state.Available_Missions.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-2 text-zinc-500">
                          <Target className="w-4 h-4 text-emerald-500" />
                          <span className="text-[10px] uppercase font-bold text-emerald-500/80">Nhiệm Vụ Khả Dụng</span>
                        </div>
                        <div className="flex flex-col gap-2">
                          {state.Available_Missions.map((mission: any, i) => (
                            <div key={i} className="p-2 bg-emerald-500/5 border border-emerald-500/10 rounded-lg">
                              <div className="font-mono text-emerald-400 text-xs font-bold mb-1">{mission.Mission_Name}</div>
                              <div className="text-[10px] text-zinc-400 leading-relaxed mb-1">{mission.Description}</div>
                              <div className="flex justify-between items-center text-[10px] mt-2 pt-1 border-t border-emerald-500/10">
                                <span className="text-red-400/80">Độ khó: {mission.Difficulty}</span>
                                <span className="text-yellow-400/80 font-bold">Thưởng: {mission.Reward}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {state.Available_Shop_Items && state.Available_Shop_Items.length > 0 && (
                      <div className={state.Available_Missions?.length > 0 ? "pt-3 border-t border-zinc-800" : ""}>
                        <div className="flex items-center gap-2 mb-2 text-zinc-500">
                          <Store className="w-4 h-4 text-yellow-500" />
                          <span className="text-[10px] uppercase font-bold text-yellow-500/80">Cửa Hàng / Giao Dịch</span>
                        </div>
                        <div className="flex flex-col gap-2">
                          {state.Available_Shop_Items.map((item: any, i) => (
                            <div key={i} className="p-2 bg-yellow-500/5 border border-yellow-500/10 rounded-lg">
                              <div className="flex justify-between items-start mb-1">
                                <span className="font-mono text-yellow-400 text-xs font-bold">{item.Item_Name}</span>
                                <span className="text-[10px] font-bold text-yellow-500/80 bg-yellow-500/10 px-1.5 py-0.5 rounded">{item.Price}</span>
                              </div>
                              <div className="text-[10px] text-zinc-400 leading-relaxed">{item.Description}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div className="mt-3 pt-2 border-t border-zinc-800/50 text-center">
                      <p className="text-[9px] text-zinc-500 italic">💡 Gõ vào khung chat để nhận nhiệm vụ hoặc mua vật phẩm (VD: "Tôi muốn mua Tụ Khí Đan").</p>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* World Variables */}
      <section className="p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
        <button 
          onClick={() => setIsWorldOpen(!isWorldOpen)}
          className="w-full flex items-center justify-between group"
        >
          <div className="flex items-center gap-2 text-emerald-500">
            <Clock className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wider text-xs">Thế Giới</h3>
          </div>
          {isWorldOpen ? <ChevronDown className="w-4 h-4 text-zinc-500 group-hover:text-emerald-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-emerald-400 transition-colors" />}
        </button>
        <AnimatePresence>
          {isWorldOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="space-y-3 mt-4">
                <div className="flex items-start gap-3">
                  <Activity className={`w-4 h-4 mt-0.5 ${state.Pacing_State === 'Action' ? 'text-red-500' : 'text-blue-400'}`} />
                  <div>
                    <span className="text-zinc-500 text-[10px] uppercase block">Nhịp Độ</span>
                    <span className={`text-sm font-bold ${state.Pacing_State === 'Action' ? 'text-red-400' : 'text-blue-300'}`}>
                      {state.Pacing_State || 'Downtime'}
                    </span>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-zinc-500 mt-0.5" />
                  <div className="flex-1">
                    <span className="text-zinc-500 text-[10px] uppercase block">Vị Trí</span>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-zinc-200">{state.World_Variables.Current_Location}</span>
                      {onGenerateMap && (
                        <button 
                          onClick={onGenerateMap}
                          disabled={isGeneratingMap}
                          className="p-1.5 bg-zinc-800 hover:bg-zinc-700 rounded-md text-zinc-400 hover:text-white transition-colors disabled:opacity-50"
                          title="Vẽ bản đồ khu vực này"
                        >
                          {isGeneratingMap ? <Loader2 className="w-3 h-3 animate-spin" /> : <Map className="w-3 h-3" />}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="w-4 h-4 text-zinc-500 mt-0.5" />
                  <div className="flex-1">
                    <span className="text-zinc-500 text-[10px] uppercase block">Thời Gian</span>
                    <span className="text-sm text-zinc-200 block">{state.World_Variables.Time_Passed}</span>
                    {state.World_Variables.In_World_Time && (
                      <div className="mt-2 p-2 bg-zinc-950/50 rounded-lg border border-zinc-800/50 space-y-1.5">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] text-zinc-500 uppercase">Ngày</span>
                          <span className="text-xs font-mono text-emerald-400 font-bold">{state.World_Variables.In_World_Time.Current_Day}</span>
                        </div>
                        <div className="text-[10px] text-zinc-400">
                          <span className="text-zinc-500 uppercase mr-1">Đã qua:</span>
                          {state.World_Variables.In_World_Time.Elapsed_Time}
                        </div>
                        <div className="text-[10px] text-zinc-400">
                          <span className="text-zinc-500 uppercase mr-1">Thời hạn:</span>
                          <span className="text-orange-400/80">{state.World_Variables.In_World_Time.Deadline_Status}</span>
                        </div>
                        <div className="text-[10px] text-zinc-400">
                          <span className="text-zinc-500 uppercase mr-1">Chuẩn bị:</span>
                          <span className="text-blue-400/80">{state.World_Variables.In_World_Time.Preparation_Level}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Zap className="w-4 h-4 text-yellow-500 mt-0.5" />
                  <div>
                    <span className="text-zinc-500 text-[10px] uppercase block">Thời Tiết</span>
                    <span className="text-sm text-zinc-200">{state.World_Variables.Current_Weather || 'Nắng'}</span>
                  </div>
                </div>
                {state.World_Variables.Random_Event_Active && state.World_Variables.Random_Event_Active !== 'None' && (
                  <div className="flex items-start gap-3 p-2 bg-orange-500/10 rounded-lg border border-orange-500/20">
                    <AlertTriangle className="w-4 h-4 text-orange-500 mt-0.5" />
                    <div>
                      <span className="text-orange-500 text-[10px] uppercase block font-bold">Sự Kiện Đang Diễn Ra</span>
                      <span className="text-sm text-orange-200">{state.World_Variables.Random_Event_Active}</span>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* Lorebook */}
      {state.Lorebook && (
        <section className="p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
          <button 
            onClick={() => setIsLorebookOpen(!isLorebookOpen)}
            className="w-full flex items-center justify-between group"
          >
            <div className="flex items-center gap-2 text-purple-400">
              <BookOpen className="w-5 h-5" />
              <h3 className="font-bold uppercase tracking-wider text-xs">Lorebook</h3>
            </div>
            {isLorebookOpen ? <ChevronDown className="w-4 h-4 text-zinc-500 group-hover:text-purple-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-purple-400 transition-colors" />}
          </button>
          <AnimatePresence>
            {isLorebookOpen && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="space-y-4 pt-4">
                  {state.Lorebook.Cultivation_System && state.Lorebook.Cultivation_System.length > 0 && (
                    <div>
                      <span className="text-zinc-500 text-[10px] uppercase block mb-1">Hệ Thống Tu Luyện</span>
                      <ul className="space-y-1">
                        {state.Lorebook.Cultivation_System.map((sys, i) => (
                          <li key={i} className="text-xs text-purple-200/70 leading-relaxed flex gap-2">
                            <span className="text-purple-500">•</span>
                            {sys}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {state.Lorebook.Key_Factions && state.Lorebook.Key_Factions.length > 0 && (
                    <div>
                      <span className="text-zinc-500 text-[10px] uppercase block mb-1">Thế Lực Chính</span>
                      <ul className="space-y-1">
                        {state.Lorebook.Key_Factions.map((faction, i) => (
                          <li key={i} className="text-xs text-purple-200/70 leading-relaxed flex gap-2">
                            <span className="text-purple-500">•</span>
                            {faction}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {state.Lorebook.World_Rules && state.Lorebook.World_Rules.length > 0 && (
                    <div>
                      <span className="text-zinc-500 text-[10px] uppercase block mb-1">Quy Tắc Thế Giới</span>
                      <ul className="space-y-1">
                        {state.Lorebook.World_Rules.map((rule, i) => (
                          <li key={i} className="text-xs text-purple-200/70 leading-relaxed flex gap-2">
                            <span className="text-purple-500">•</span>
                            {rule}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {state.Lorebook.World_Map && state.Lorebook.World_Map.length > 0 && (
                    <div>
                      <span className="text-zinc-500 text-[10px] uppercase block mb-1">Bản Đồ Thế Giới (Nguyên Tác)</span>
                      <div className="space-y-2">
                        {state.Lorebook.World_Map.map((loc: any, i: number) => (
                          <div key={i} className="p-2 bg-purple-500/5 border border-purple-500/10 rounded-lg">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs font-bold text-purple-400">{loc.Location_Name}</span>
                              <span className="text-[9px] text-zinc-500 uppercase">{loc.Importance}</span>
                            </div>
                            <p className="text-[10px] text-zinc-400 leading-relaxed">{loc.Description}</p>
                            {loc.Sub_Locations && loc.Sub_Locations.length > 0 && (
                              <div className="text-[9px] text-zinc-500 mt-1">
                                Địa điểm con: {loc.Sub_Locations.join(', ')}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      )}

      {/* Current Arc Summary */}
      {state.Current_Arc_Summary && (
        <section className="p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
          <button 
            onClick={() => setIsArcSummaryOpen(!isArcSummaryOpen)}
            className="w-full flex items-center justify-between group"
          >
            <div className="flex items-center gap-2 text-amber-500">
              <ScrollText className="w-5 h-5" />
              <h3 className="font-bold uppercase tracking-wider text-xs">Tóm Tắt Arc Hiện Tại</h3>
            </div>
            {isArcSummaryOpen ? <ChevronDown className="w-4 h-4 text-zinc-500 group-hover:text-amber-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-amber-400 transition-colors" />}
          </button>
          <AnimatePresence>
            {isArcSummaryOpen && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <p className="text-xs text-zinc-300 leading-relaxed italic border-l-2 border-amber-500/30 pl-3 mt-4">
                  {state.Current_Arc_Summary}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      )}

      {/* Global Context Engine */}
      {state.Global_Context && (
        <section className="p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
          <button 
            onClick={() => setIsGlobalContextOpen(!isGlobalContextOpen)}
            className="w-full flex items-center justify-between group"
          >
            <div className="flex items-center gap-2 text-sky-500">
              <Map className="w-5 h-5" />
              <h3 className="font-bold uppercase tracking-wider text-xs">Bối Cảnh Khu Vực</h3>
            </div>
            {isGlobalContextOpen ? <ChevronDown className="w-4 h-4 text-zinc-500 group-hover:text-sky-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-sky-400 transition-colors" />}
          </button>
          <AnimatePresence>
            {isGlobalContextOpen && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="space-y-4 mt-4">
                  <div>
                    <span className="text-zinc-500 text-[10px] uppercase block mb-1">Cơ Cấu Tổ Chức</span>
                    <p className="text-xs text-zinc-300 leading-relaxed">{state.Global_Context.Organization_Hierarchy}</p>
                  </div>
                  
                  {state.Global_Context.Entities_Present && state.Global_Context.Entities_Present.length > 0 && (
                    <div>
                      <span className="text-zinc-500 text-[10px] uppercase block mb-1">Thực Thể Hiện Hữu</span>
                      <ul className="space-y-1">
                        {state.Global_Context.Entities_Present.map((entity, i) => (
                          <li key={i} className="text-xs text-sky-200/70 leading-relaxed flex gap-2">
                            <span className="text-sky-500">•</span>
                            {entity}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {state.Global_Context.Local_Resources && state.Global_Context.Local_Resources.length > 0 && (
                    <div>
                      <span className="text-zinc-500 text-[10px] uppercase block mb-1">Tài Nguyên Khu Vực</span>
                      <ul className="space-y-1">
                        {state.Global_Context.Local_Resources.map((resource, i) => (
                          <li key={i} className="text-xs text-emerald-200/70 leading-relaxed flex gap-2">
                            <span className="text-emerald-500">•</span>
                            {resource}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div>
                    <span className="text-zinc-500 text-[10px] uppercase block mb-1">Bản Đồ Khám Phá</span>
                    {Array.isArray(state.Global_Context.Conceptual_Map) ? (
                      <div className="space-y-2">
                        {state.Global_Context.Conceptual_Map.map((loc: any, i: number) => (
                          <div key={i} className="p-2 bg-zinc-950/50 rounded-lg border border-zinc-800/50">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs font-bold text-sky-400">{loc.Location}</span>
                              <span className="text-[9px] text-zinc-500 uppercase">{loc.Status}</span>
                            </div>
                            <p className="text-[10px] text-zinc-400 leading-relaxed mb-1">{loc.Description}</p>
                            {loc.Connected_To && loc.Connected_To.length > 0 && (
                              <div className="text-[9px] text-zinc-500 italic">
                                Kết nối: {loc.Connected_To.join(', ')}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-zinc-300 leading-relaxed italic">{state.Global_Context.Conceptual_Map}</p>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      )}

      {/* Dice Roll Log */}
      {state.Dice_Roll_Log && (
        <section className="p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
          <button 
            onClick={() => setIsDiceRollOpen(!isDiceRollOpen)}
            className="w-full flex items-center justify-between group"
          >
            <div className="flex items-center gap-2 text-yellow-500">
              <Dices className="w-5 h-5" />
              <h3 className="font-bold uppercase tracking-wider text-xs">Kết Quả Đổ Xúc Xắc</h3>
            </div>
            {isDiceRollOpen ? <ChevronDown className="w-4 h-4 text-zinc-500 group-hover:text-yellow-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-yellow-400 transition-colors" />}
          </button>
          <AnimatePresence>
            {isDiceRollOpen && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="space-y-3 text-xs mt-4">
                  <div>
                    <span className="text-zinc-500 block mb-1">Hành động:</span>
                    <span className="text-zinc-300">{state.Dice_Roll_Log.Action_Attempted}</span>
                  </div>
                  <div className="flex justify-between items-center bg-zinc-950 p-2 rounded-lg">
                    <span className="text-zinc-500">Base Roll:</span>
                    <span className="font-mono text-yellow-400 font-bold">{state.Dice_Roll_Log.Base_Roll}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block mb-1">Hệ số (Modifiers):</span>
                    <span className="text-zinc-400 italic">{state.Dice_Roll_Log.Modifiers}</span>
                  </div>
                  <div className="flex justify-between items-center bg-zinc-950 p-2 rounded-lg border border-zinc-800">
                    <span className="text-zinc-500 font-bold">Tổng Điểm:</span>
                    <span className={`font-mono font-bold text-lg ${parseInt(state.Dice_Roll_Log.Final_Score) < 10 ? 'text-red-500' : parseInt(state.Dice_Roll_Log.Final_Score) >= 15 ? 'text-emerald-500' : 'text-yellow-500'}`}>
                      {state.Dice_Roll_Log.Final_Score}
                    </span>
                  </div>
                  <div className="pt-2 border-t border-zinc-800">
                    <span className="text-zinc-500 block mb-1">Logic:</span>
                    <span className="text-zinc-300 italic">{state.Dice_Roll_Log.Result_Logic}</span>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      )}

      {/* Long Term Goals */}
      {state.Long_Term_Goals && state.Long_Term_Goals.length > 0 && (
        <section className="p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
          <button 
            onClick={() => setIsLongTermGoalsOpen(!isLongTermGoalsOpen)}
            className="w-full flex items-center justify-between group"
          >
            <div className="flex items-center gap-2 text-cyan-500">
              <Target className="w-5 h-5" />
              <h3 className="font-bold uppercase tracking-wider text-xs">Mục Tiêu Dài Hạn</h3>
            </div>
            {isLongTermGoalsOpen ? <ChevronDown className="w-4 h-4 text-zinc-500 group-hover:text-cyan-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-cyan-400 transition-colors" />}
          </button>
          <AnimatePresence>
            {isLongTermGoalsOpen && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <ul className="space-y-2 mt-4">
                  {state.Long_Term_Goals.map((goal, i) => (
                    <li key={i} className="text-xs text-cyan-200/70 leading-relaxed flex gap-2">
                      <span className="text-cyan-500">•</span>
                      {goal}
                    </li>
                  ))}
                </ul>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      )}

      {/* NPC Tracker */}
      <section className="p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
        <button 
          onClick={() => setIsNpcTrackerOpen(!isNpcTrackerOpen)}
          className="w-full flex items-center justify-between group"
        >
          <div className="flex items-center gap-2 text-purple-500">
            <Users className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wider text-xs">NPC Quan Trọng</h3>
          </div>
          {isNpcTrackerOpen ? <ChevronDown className="w-4 h-4 text-zinc-500 group-hover:text-purple-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-purple-400 transition-colors" />}
        </button>
        <AnimatePresence>
          {isNpcTrackerOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="space-y-4 mt-4">
                {state.NPC_Tracker?.map((npc, i) => {
                  const isNegative = npc.Relationship_Score < 0;
                  const isPositive = npc.Relationship_Score > 0;
                  const colorClass = isNegative ? 'text-red-400' : isPositive ? 'text-blue-400' : 'text-zinc-400';
                  const barColorClass = isNegative ? 'bg-red-500' : isPositive ? 'bg-blue-500' : 'bg-zinc-500';
                  
                  return (
                    <div key={i} className="group">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-bold text-zinc-200">{npc.Name}</span>
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-bold uppercase tracking-tighter ${colorClass}`}>
                            {npc.Relationship_Status}
                          </span>
                          <span className="text-[10px] font-mono text-zinc-500">
                            ({npc.Relationship_Score > 0 ? '+' : ''}{npc.Relationship_Score})
                          </span>
                        </div>
                      </div>
                      <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
                        <div 
                          className={`h-full transition-all duration-500 ${barColorClass}`}
                          style={{ width: `${Math.min(100, Math.max(0, (npc.Relationship_Score + 100) / 2))}%` }}
                        />
                      </div>
                      <p className="text-[10px] text-zinc-500 mt-2 italic">
                        Mưu đồ: {npc.Hidden_Agenda}
                      </p>
                    </div>
                  );
                })}
                {(!state.NPC_Tracker || state.NPC_Tracker.length === 0) && (
                  <p className="text-[10px] text-zinc-600 italic">Chưa phát hiện NPC nào...</p>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* Faction Tracker */}
      <section className="p-4 bg-zinc-900 rounded-2xl border border-zinc-800">
        <button 
          onClick={() => setIsFactionTrackerOpen(!isFactionTrackerOpen)}
          className="w-full flex items-center justify-between group"
        >
          <div className="flex items-center gap-2 text-indigo-400">
            <Flag className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wider text-xs">Thế Lực Ngầm</h3>
          </div>
          {isFactionTrackerOpen ? <ChevronDown className="w-4 h-4 text-zinc-500 group-hover:text-indigo-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-indigo-400 transition-colors" />}
        </button>
        <AnimatePresence>
          {isFactionTrackerOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="space-y-4 mt-4">
                {state.Faction_Tracker?.map((faction, i) => (
                  <div key={i} className="group">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-bold text-zinc-200">{faction.Name}</span>
                    </div>
                    <p className="text-[10px] text-zinc-400 uppercase tracking-wider mb-1">
                      Danh vọng: <span className="text-indigo-300">{faction.Reputation}</span>
                    </p>
                    <p className="text-[10px] text-zinc-500 italic">
                      {faction.Status}
                    </p>
                  </div>
                ))}
                {(!state.Faction_Tracker || state.Faction_Tracker.length === 0) && (
                  <p className="text-[10px] text-zinc-600 italic">Chưa tiếp xúc thế lực nào...</p>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* Unresolved Consequences */}
      <section className="p-4 bg-orange-950/20 rounded-2xl border border-orange-900/30">
        <button 
          onClick={() => setIsConsequencesOpen(!isConsequencesOpen)}
          className="w-full flex items-center justify-between group"
        >
          <div className="flex items-center gap-2 text-orange-400">
            <AlertTriangle className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wider text-xs">Hệ Quả Tiềm Tàng</h3>
          </div>
          {isConsequencesOpen ? <ChevronDown className="w-4 h-4 text-orange-900/50 group-hover:text-orange-400 transition-colors" /> : <ChevronRight className="w-4 h-4 text-orange-900/50 group-hover:text-orange-400 transition-colors" />}
        </button>
        <AnimatePresence>
          {isConsequencesOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <ul className="space-y-2 mt-4">
                {state.Unresolved_Consequences?.map((con, i) => (
                  <li key={i} className="text-xs text-orange-200/70 leading-relaxed flex gap-2">
                    <span className="text-orange-500">•</span>
                    {con}
                  </li>
                ))}
                {(!state.Unresolved_Consequences || state.Unresolved_Consequences.length === 0) && (
                  <li className="text-[10px] text-zinc-600 italic">Mọi thứ vẫn trong tầm kiểm soát...</li>
                )}
              </ul>
            </motion.div>
          )}
        </AnimatePresence>
      </section>
    </div>
  );
}
