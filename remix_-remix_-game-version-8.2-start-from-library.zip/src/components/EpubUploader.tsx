import React, { useState, useRef } from 'react';
import { Upload, Book, Loader2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { parseEpubFile } from '../utils/epubParser';

interface EpubUploaderProps {
  onContentExtracted: (content: string) => void;
}

export default function EpubUploader({ onContentExtracted }: EpubUploaderProps) {
  const [isExtracting, setIsExtracting] = useState(false);
  const [progressMessage, setProgressMessage] = useState('ĐANG PHÂN TÍCH THẾ GIỚI QUAN...');
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.epub')) {
      setError('Vui lòng tải lên tệp định dạng .epub');
      return;
    }

    setIsExtracting(true);
    setProgressMessage('ĐANG PHÂN TÍCH THẾ GIỚI QUAN...');
    setError(null);

    try {
      const reader = new FileReader();
      reader.onerror = () => {
        setError('Lỗi khi đọc tệp từ đĩa.');
        setIsExtracting(false);
      };

      reader.onload = async (event) => {
        try {
          const arrayBuffer = event.target?.result as ArrayBuffer;
          if (!arrayBuffer) {
            throw new Error("Không thể đọc dữ liệu tệp.");
          }

          const extractedText = await parseEpubFile(arrayBuffer, setProgressMessage);

          if (extractedText.trim().length < 100) {
            throw new Error('Nội dung trích xuất quá ngắn. Thử tệp EPUB khác có nhiều văn bản hơn.');
          }

          onContentExtracted(extractedText);
        } catch (err: any) {
          console.error("Extraction error:", err);
          setError(err.message || 'Lỗi khi xử lý tệp EPUB.');
        } finally {
          setIsExtracting(false);
        }
      };
      reader.readAsArrayBuffer(file);
    } catch (err: any) {
      console.error("File handle error:", err);
      setError('Lỗi khi tải tệp.');
      setIsExtracting(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-zinc-800 rounded-3xl bg-zinc-900/50 backdrop-blur-sm">
      <AnimatePresence mode="wait">
        {isExtracting ? (
          <motion.div
            key="loading"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="flex flex-col items-center gap-4"
          >
            <Loader2 className="w-12 h-12 text-orange-500 animate-spin" />
            <div className="text-center">
              <p className="text-zinc-400 font-mono text-sm animate-pulse mb-2">{progressMessage}</p>
              <p className="text-zinc-500 text-xs">Quá trình này có thể mất 10-20 giây với các bộ truyện dài (hàng trăm chương).</p>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="upload"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center gap-6"
          >
            <div className="p-6 bg-orange-500/10 rounded-full">
              <Book className="w-12 h-12 text-orange-500" />
            </div>
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Tải lên Truyện Gốc</h3>
              <p className="text-zinc-400 text-sm max-w-xs">
                GM sẽ dựa vào nội dung EPUB này để vận hành thế giới.
              </p>
            </div>
            
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-8 py-3 bg-white text-black font-bold rounded-full hover:bg-orange-500 hover:text-white transition-all duration-300 flex items-center gap-2 group"
            >
              <Upload className="w-5 h-5 group-hover:-translate-y-1 transition-transform" />
              CHỌN TỆP EPUB
            </button>
            
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".epub"
              className="hidden"
            />

            {error && (
              <div className="flex items-center gap-2 text-red-400 text-sm bg-red-400/10 px-4 py-2 rounded-lg">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
