import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle } from 'lucide-react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      let errorMessage = "Đã có lỗi xảy ra. Vui lòng thử lại sau.";
      let errorDetails = "";

      try {
        if (this.state.error?.message) {
          const parsedError = JSON.parse(this.state.error.message);
          if (parsedError.error && parsedError.operationType) {
            errorMessage = "Lỗi quyền truy cập dữ liệu (Missing or insufficient permissions).";
            errorDetails = `Thao tác: ${parsedError.operationType}\nĐường dẫn: ${parsedError.path}\nChi tiết: ${parsedError.error}`;
          }
        }
      } catch (e) {
        // Not a JSON error, fallback to normal message
        errorDetails = this.state.error?.message || "";
      }

      return (
        <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-red-900/50 rounded-xl p-6 max-w-md w-full shadow-2xl">
            <div className="flex items-center gap-3 text-red-500 mb-4">
              <AlertTriangle className="w-8 h-8" />
              <h2 className="text-xl font-bold">Lỗi Ứng Dụng</h2>
            </div>
            <p className="text-zinc-300 mb-4">
              {errorMessage}
            </p>
            {errorDetails && (
              <pre className="bg-zinc-950 p-3 rounded-lg text-xs text-red-400/80 overflow-auto whitespace-pre-wrap border border-zinc-800">
                {errorDetails}
              </pre>
            )}
            <button
              onClick={() => window.location.reload()}
              className="mt-6 w-full py-2 px-4 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
            >
              Tải lại trang
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
