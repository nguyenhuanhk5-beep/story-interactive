import { set, get, del, keys } from 'idb-keyval';
import { WorldSave } from '../App';

const WORLDS_KEY_PREFIX = 'world_';

export async function saveWorldToLocalDB(world: WorldSave) {
  try {
    await set(`${WORLDS_KEY_PREFIX}${world.id}`, world);
  } catch (e) {
    console.error("Failed to save world to local DB", e);
  }
}

export async function loadWorldsFromLocalDB(): Promise<WorldSave[]> {
  try {
    const allKeys = await keys();
    const worldKeys = allKeys.filter(k => typeof k === 'string' && k.startsWith(WORLDS_KEY_PREFIX));
    
    const worlds: WorldSave[] = [];
    for (const key of worldKeys) {
      const world = await get<WorldSave>(key as string);
      if (world) {
        worlds.push(world);
      }
    }
    
    // Sort by timestamp descending
    return worlds.sort((a, b) => b.timestamp - a.timestamp);
  } catch (e) {
    console.error("Failed to load worlds from local DB", e);
    return [];
  }
}

export async function deleteWorldFromLocalDB(worldId: string) {
  try {
    await del(`${WORLDS_KEY_PREFIX}${worldId}`);
  } catch (e) {
    console.error("Failed to delete world from local DB", e);
  }
}
