import Fuse from 'fuse.js';
import { set, get, del } from 'idb-keyval';

export interface Chunk {
  id: number;
  text: string;
  orderIndex: number;
  sourceZone: 'start' | 'middle' | 'end';
}

let fuseIndex: Fuse<Chunk> | null = null;
let chunks: Chunk[] = [];

export function getChunks(): Chunk[] {
  return chunks;
}

export function loadChunks(savedChunks: Chunk[]) {
  chunks = savedChunks;
  fuseIndex = new Fuse(chunks, {
    keys: ['text'],
    includeScore: true,
    threshold: 0.4,
    ignoreLocation: true,
    minMatchCharLength: 3,
    useExtendedSearch: true,
  });
}

export async function saveChunksToDB(worldId: string) {
  if (chunks.length > 0) {
    try {
      await set(`rag_chunks_${worldId}`, chunks);
    } catch (e) {
      console.error("Failed to save chunks to IndexedDB", e);
    }
  }
}

export async function loadChunksFromDB(worldId: string): Promise<boolean> {
  try {
    const savedChunks = await get<Chunk[]>(`rag_chunks_${worldId}`);
    if (savedChunks && savedChunks.length > 0) {
      loadChunks(savedChunks);
      return true;
    }
  } catch (e) {
    console.error("Failed to load chunks from IndexedDB", e);
  }
  return false;
}

export async function deleteChunksFromDB(worldId: string) {
  try {
    await del(`rag_chunks_${worldId}`);
  } catch (e) {
    console.error("Failed to delete chunks from IndexedDB", e);
  }
}

export function processAndIndexText(fullText: string, chunkSize = 1500): number {
  chunks = [];
  // Simple chunking by length, respecting paragraph breaks if possible
  const paragraphs = fullText.split(/\n\s*\n/);
  let currentChunk = "";
  let id = 0;
  let orderIndex = 0;
  let currentZone: 'start' | 'middle' | 'end' = 'start';

  for (const p of paragraphs) {
    if (p.includes('[PHẦN ĐẦU TRUYỆN:]')) {
      currentZone = 'start';
      continue;
    } else if (p.includes('[... ĐOẠN TRÍCH GIỮA TRUYỆN ...]')) {
      currentZone = 'middle';
      continue;
    } else if (p.includes('[PHẦN KẾT THÚC CỦA TRUYỆN')) {
      currentZone = 'end';
      continue;
    }

    if (currentChunk.length + p.length > chunkSize && currentChunk.length > 0) {
      chunks.push({ id: id++, text: currentChunk.trim(), orderIndex: orderIndex++, sourceZone: currentZone });
      currentChunk = "";
    }
    currentChunk += p + "\n\n";
  }
  if (currentChunk.trim().length > 0) {
    chunks.push({ id: id++, text: currentChunk.trim(), orderIndex: orderIndex++, sourceZone: currentZone });
  }

  // Initialize Fuse.js for fuzzy searching
  fuseIndex = new Fuse(chunks, {
    keys: ['text'],
    includeScore: true,
    threshold: 0.4, // Lower threshold for stricter matching
    ignoreLocation: true,
    minMatchCharLength: 3,
    useExtendedSearch: true,
  });

  return chunks.length;
}

const STOP_WORDS = new Set([
  'không', 'có', 'là', 'và', 'của', 'để', 'cho', 'với', 'những', 'các', 'một', 'sự', 'rõ', 'biết', 'thì', 'mà', 'như', 'này', 'đó', 'đây', 'kia', 'nào', 'tôi', 'bạn', 'hắn', 'y', 'thị', 'chúng', 'ta', 'đã', 'đang', 'sẽ', 'được', 'bị', 'ở', 'trong', 'ngoài', 'trên', 'dưới', 'trước', 'sau', 'khi', 'lúc', 'nếu', 'tuy', 'nhưng', 'bởi', 'vì', 'nên', 'rất', 'quá', 'lắm', 'hơi', 'cũng', 'vẫn', 'cứ', 'lại', 'mới', 'vừa', 'đều', 'chỉ', 'thêm', 'bớt', 'nhiều', 'ít', 'vài', 'chút', 'làm', 'đi', 'đến', 'ra', 'vào', 'lên', 'xuống', 'qua', 'lại', 'thấy', 'nhìn', 'nghe', 'nói', 'hỏi', 'đáp', 'rằng', 'rồi', 'chưa', 'xong',
  'anh', 'chị', 'em', 'ông', 'bà', 'cha', 'mẹ', 'con', 'cháu', 'vợ', 'chồng', 'người', 'nhà', 'nước', 'trời', 'đất', 'ngày', 'đêm', 'sáng', 'chiều', 'tối', 'năm', 'tháng', 'tuần', 'giờ', 'phút', 'giây', 'nơi', 'chỗ', 'việc', 'cái', 'chiếc', 'con', 'quyển', 'tờ', 'bản', 'vật', 'điều', 'thứ', 'loại', 'hạng', 'mọi', 'mỗi', 'từng', 'cả', 'hết', 'toàn', 'bộ', 'phần', 'nửa', 'ít', 'nhiều', 'khoảng', 'chừng', 'tầm', 'độ', 'đến', 'tới', 'lui', 'về', 'qua', 'lại', 'ra', 'vào', 'lên', 'xuống', 'sang', 'ngang', 'dọc', 'trong', 'ngoài', 'trước', 'sau', 'giữa', 'cạnh', 'bên', 'phía', 'hướng', 'đầu', 'cuối', 'mặt', 'lưng', 'tay', 'chân', 'mắt', 'mũi', 'miệng', 'tai', 'đầu', 'tóc', 'da', 'thân', 'mình', 'hồn', 'phách', 'khí', 'lực', 'thần', 'tâm', 'ý', 'tình', 'cảm', 'nghĩ', 'tưởng', 'nhớ', 'quên', 'hiểu', 'biết', 'tin', 'nghi', 'sợ', 'lo', 'buồn', 'vui', 'giận', 'ghét', 'yêu', 'thương', 'muốn', 'cần', 'nên', 'phải', 'đáng', 'hay', 'giỏi', 'kém', 'tệ', 'xấu', 'tốt', 'đẹp', 'xinh', 'cao', 'thấp', 'lớn', 'nhỏ', 'to', 'bé', 'dài', 'ngắn', 'rộng', 'hẹp', 'nặng', 'nhẹ', 'nhanh', 'chậm', 'sớm', 'muộn', 'đúng', 'sai', 'thật', 'giả', 'cũ', 'mới', 'khác', 'giống', 'nhau', 'cùng', 'riêng', 'chung', 'tự', 'chính', 'vốn', 'dĩ', 'thực', 'quả', 'vậy', 'thế', 'nào', 'sao', 'đâu', 'ai', 'gì', 'bao', 'nhiêu', 'mấy', 'nào'
]);

export interface RetrievalQuery {
  text: string;
  mode: 'action' | 'memory';
  currentTurn: number;
  historyContext?: string[];
}

export function retrieveContext(query: RetrievalQuery, topK = 3): string[] {
  // Extract meaningful words
  const words = query.text.toLowerCase().split(/[\s,.;!?()]+/);
  const meaningfulWords = words.filter(w => w.length > 2 && !STOP_WORDS.has(w));
  
  if (meaningfulWords.length === 0) {
    // If no meaningful words, don't return random context
    return [];
  }

  // Use extended search syntax for better matching
  const searchTerms = meaningfulWords.map(w => `'${w}`).join(' ');
  const finalQuery = searchTerms.length > 0 ? searchTerms : query.text;
  
  // TẦNG 1: Canon History / Snapshot hiện có
  if (query.mode === 'memory' && query.historyContext && query.historyContext.length > 0) {
    const historyChunks = query.historyContext.map((text, idx) => ({ id: idx, text }));
    const historyFuse = new Fuse(historyChunks, {
      keys: ['text'],
      includeScore: true,
      threshold: 0.4,
      ignoreLocation: true,
      minMatchCharLength: 3,
      useExtendedSearch: true,
    });
    const historyResults = historyFuse.search(finalQuery, { limit: topK });
    const goodHistoryResults = historyResults.filter(r => (r.score || 1) < 0.35).map(r => r.item.text);
    
    // Nếu tìm thấy trong history, ưu tiên trả về luôn
    if (goodHistoryResults.length > 0) {
      return goodHistoryResults;
    }
  }

  if (!fuseIndex) return [];

  // TẦNG 2: Canon EPUB đã được mở khóa theo timeline
  const results = fuseIndex.search(finalQuery, { limit: topK * 3 }); // Get more to filter
  
  // Temporal gating heuristic
  const safeResults = results.filter(r => {
    const chunk = r.item;
    // Giả định (currentTurn là số message trong history, mỗi turn có 2 message): 
    // < 30 message (15 turn): chỉ an toàn dùng phần đầu
    // 30 - 80 message (15 - 40 turn): an toàn dùng phần đầu và giữa
    // > 80 message: có thể dùng phần cuối
    if (query.currentTurn <= 30) {
      return chunk.sourceZone === 'start';
    } else if (query.currentTurn <= 80) {
      return chunk.sourceZone === 'start' || chunk.sourceZone === 'middle';
    }
    return true;
  });

  // TẦNG 3: Trả về kết quả an toàn hoặc rỗng
  return safeResults
    .filter(r => (r.score || 1) < 0.35)
    .slice(0, topK)
    .map(r => r.item.text);
}
