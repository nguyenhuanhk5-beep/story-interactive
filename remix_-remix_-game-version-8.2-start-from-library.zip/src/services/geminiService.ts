import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";

function getAIClient() {
  return new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
}

export interface GameState {
  Game_Status: string;
  Pacing_State: string;
  Dice_Roll_Log: {
    Action_Attempted: string;
    Base_Roll: string;
    Modifiers: string;
    Final_Score: string;
    Result_Logic: string;
  };
  MC_Status: {
    HP?: string;
    MP?: string;
    HP_Current: number;
    HP_Max: number;
    Resource_Label: string;
    Resource_Current: number;
    Resource_Max: number;
    Level: string;
    Skills: Array<{
      Name: string;
      Description: string;
      Usage_Hint: string;
    }>;
    Skill_Mastery: Array<{
      Base_Skill_Name: string;
      Tier: string;
      Mastered: boolean;
      Normal_Cost_Resource: number;
      Normal_Cost_HP: number;
      Notes: string;
    }>;
    Inventory: string;
    Wealth?: {
      Spirit_Stones: number;
      Merit_Points: number;
      Salary_Info: string;
    };
  };
  Long_Term_Goals: string[];
  World_Variables: {
    Time_Passed: string;
    Current_Location: string;
    Current_Weather: string;
    Random_Event_Active: string;
    In_World_Time: {
      Current_Day: number;
      Elapsed_Time: string;
      Deadline_Status: string;
      Preparation_Level: string;
    };
  };
  Global_Context: {
    Organization_Hierarchy: string;
    Entities_Present: string[];
    Local_Resources: string[];
    Conceptual_Map: string | Array<{
      Location: string;
      Status: string;
      Description: string;
      Connected_To: string[];
    }>;
  };
  NPC_Tracker: Array<{
    Name: string;
    Relationship_Status: string;
    Relationship_Score: number;
    Hidden_Agenda: string;
  }>;
  Faction_Tracker: Array<{
    Name: string;
    Reputation: string;
    Status: string;
  }>;
  Unresolved_Consequences: string[];
  Logical_Corrections: string[];
  Invalid_Entities?: string[];
  Known_Entities?: string[];
  Available_Missions?: Array<{
    Mission_Name: string;
    Difficulty: string;
    Reward: string;
    Description: string;
  }>;
  Available_Shop_Items?: Array<{
    Item_Name: string;
    Price: string;
    Description: string;
  }>;
  Lorebook?: {
    Cultivation_System: string[];
    Key_Factions: string[];
    World_Rules: string[];
    World_Map?: Array<{
      Location_Name: string;
      Description: string;
      Parent_Location?: string;
      Sub_Locations?: string[];
      Importance: string;
    }>;
  };
  Current_Arc_Summary?: string;
}

export interface GMResponse {
  continuity_check?: string;
  story: string;
  choices: string[];
  state: GameState;
}

const SYSTEM_INSTRUCTION = `
# VAI TRÒ CỦA BẠN
Bạn là một **Game Master (GM) tàn nhẫn, logic và khách quan**. Nhiệm vụ của bạn là vận hành một thế giới tu tiên khắc nghiệt, nơi mọi hành động đều có nhân quả và cái giá phải trả.

# QUY TRÌNH TƯ DUY (THINKING PROCESS) - BẮT BUỘC
Trước khi đưa ra phản hồi JSON, bạn PHẢI ngầm thực hiện:
1. **Phân tích Nhân Quả**: Hành động này gây ra "Hiệu ứng Hồ Điệp" gì? Có NPC nào đang quan sát ngầm không?
2. **Tính toán RNG**: Đổ xúc xắc ngầm (1-20) + hệ số (Tu vi: +/-5 mỗi tầng; Vật phẩm/Hoàn cảnh: +/-2 đến 5).
3. **Đối chiếu RAG**: 
    - Nếu RAG Context chứa thông tin về nhân vật/địa điểm hiện tại: Sử dụng để làm giàu bối cảnh.
    - Nếu RAG Context chứa thông tin tương lai (spoiler): **BỎ QUA HOÀN TOÀN**.
4. **Dự báo Hậu Quả**: Ghi lại các mối nguy hiểm tiềm tàng vào 'Unresolved_Consequences'.

# HỆ THỐNG QUY TẮC CỐT LÕI

## 1. Logic Thế Giới & Giám Sát
- **Vùng An Toàn**: Cao thủ không giết người công khai nhưng sẽ dùng mưu kế, áp lực tông môn hoặc dẫn dụ yêu thú để hại người chơi.
- **Tu Vi**: Chênh lệch 2 bậc trở lên = [Không thể nhìn thấu]. Chênh lệch lớn = Áp chế tuyệt đối.

## 2. Nhịp Độ & Tài Nguyên
- **[ACTION]**: Căng thẳng, tính bằng phút. Mọi chiêu thức đều tốn Linh lực/HP.
- **[DOWNTIME]**: Tu luyện, chế đồ, tính bằng tháng/năm. Chỉ kết thúc khi có biến cố hoặc người chơi yêu cầu.
- **Thành thạo**: Kỹ năng chưa thành thạo BẮT BUỘC kích hoạt Mini-game/Thử thách.

## 3. Quyền Tự Quyết (Agency)
- Lorebook/RAG chỉ là tham khảo. Người chơi có quyền thay đổi vận mệnh, giết nhân vật chính truyện gốc, hoặc gia nhập phe phản diện.

## 4. Quản Lý Bản Đồ (Map Management)
- **Tính Nhất Quán Tuyệt Đối**: Bạn PHẢI dựa vào 'World_Map' trong Lorebook để giữ cho địa lý thế giới nhất quán. Không được tự bịa ra các địa điểm mâu thuẫn với nguyên tác.
- **Cấu Trúc Phân Cấp**: Khi cập nhật 'Conceptual_Map', hãy tổ chức theo cấp độ: Vùng lớn (Quốc gia/Châu) -> Vùng trung (Thành phố/Tông môn) -> Vùng nhỏ (Phòng/Bí cảnh).
- **Trạng Thái Khám Phá**: Đánh dấu rõ 'Status' là 'Đã khám phá' (nếu MC đã đến), 'Chưa biết' (nếu chỉ nghe kể), hoặc 'Đã biết' (nếu đã thấy từ xa).
- **Kết Nối Logic**: Luôn cập nhật 'Connected_To' để người chơi biết có thể đi đâu từ vị trí hiện tại.

## 5. Tính Liên Tục Của Nhân Vật (Character Continuity)
- **Quản lý Sự Hiện Diện**: Bạn PHẢI theo dõi sát sao vị trí và trạng thái của các nhân vật (NPC).
- **Cập nhật Trạng Thái**: Nếu một nhân vật rời đi, bị bắt, hoặc chết, bạn PHẢI cập nhật trạng thái của họ trong 'NPC_Tracker' (ví dụ: "Đã rời đi", "Bị bắt", "Đã chết") và XÓA họ khỏi 'Entities_Present' trong 'Global_Context'.
- **Chống Lỗi Logic**: Tuyệt đối KHÔNG ĐƯỢC miêu tả một nhân vật đang tương tác hoặc có mặt trong cảnh nếu họ đã rời đi hoặc bị bắt ở các diễn biến trước đó. Luôn kiểm tra 'NPC_Tracker' và 'Entities_Present' trước khi đưa nhân vật vào cảnh.

## 6. Chất Lượng Kể Chuyện
- **Giác quan**: Miêu tả ít nhất **2 giác quan** (Mùi vị, Xúc giác, Thính giác...) trong mỗi đoạn kể.
- **Chống Spoiler**: Tuyệt đối không dùng tên riêng từ tương lai. Dùng mô tả chung chung cho những thứ chưa biết tên.
- **Chống Lặp Từ**: Nếu thấy mình đang viết lặp lại câu từ, hãy dừng lại ngay và đóng khối JSON.

# CẤU TRÚC PHẢN HỒI JSON
BẮT BUỘC trả về một khối JSON duy nhất theo đúng schema.
`;

const gmResponseSchema = {
  type: Type.OBJECT,
  properties: {
    continuity_check: { type: Type.STRING, description: "BẮT BUỘC: Liệt kê ngắn gọn các nhân vật đang có mặt trong cảnh này dựa trên NPC_Tracker và Entities_Present. Ai đã chết/bị bắt/rời đi tuyệt đối không được xuất hiện." },
    story: { type: Type.STRING, description: "Nội dung diễn biến câu chuyện" },
    choices: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Các lựa chọn hành động tiếp theo" },
    state: {
      type: Type.OBJECT,
      properties: {
        Game_Status: { type: Type.STRING },
        Pacing_State: { type: Type.STRING },
        Dice_Roll_Log: {
          type: Type.OBJECT,
          properties: {
            Action_Attempted: { type: Type.STRING },
            Base_Roll: { type: Type.STRING },
            Modifiers: { type: Type.STRING },
            Final_Score: { type: Type.STRING },
            Result_Logic: { type: Type.STRING }
          }
        },
        MC_Status: {
          type: Type.OBJECT,
          properties: {
            HP_Current: { type: Type.NUMBER, description: "HP hiện tại" },
            HP_Max: { type: Type.NUMBER, description: "HP tối đa" },
            Resource_Label: { type: Type.STRING, description: "Tên tài nguyên năng lượng (VD: Linh lực, Nội lực, Mana)" },
            Resource_Current: { type: Type.NUMBER, description: "Năng lượng hiện tại" },
            Resource_Max: { type: Type.NUMBER, description: "Năng lượng tối đa" },
            Level: { type: Type.STRING },
            Skills: { 
              type: Type.ARRAY, 
              items: { 
                type: Type.OBJECT,
                properties: {
                  Name: { type: Type.STRING, description: "Tên chiêu thức" },
                  Description: { type: Type.STRING, description: "Mô tả chiêu thức" },
                  Usage_Hint: { type: Type.STRING, description: "Cách dùng hợp lý trong chiến đấu" }
                }
              } 
            },
            Skill_Mastery: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  Base_Skill_Name: { type: Type.STRING, description: "Tên gốc của kỹ năng/chiêu thức" },
                  Tier: { type: Type.STRING, description: "Cấp độ/Tầng/Hỏa của kỹ năng" },
                  Mastered: { type: Type.BOOLEAN, description: "Đã thành thạo cấp độ này chưa" },
                  Normal_Cost_Resource: { type: Type.NUMBER, description: "Lượng tài nguyên tiêu hao thông thường" },
                  Normal_Cost_HP: { type: Type.NUMBER, description: "Lượng HP tiêu hao thông thường" },
                  Notes: { type: Type.STRING, description: "Ghi chú thêm về kỹ năng" }
                }
              }
            },
            Inventory: { type: Type.STRING },
            Wealth: {
              type: Type.OBJECT,
              properties: {
                Spirit_Stones: { type: Type.NUMBER, description: "Số lượng Linh Thạch" },
                Merit_Points: { type: Type.NUMBER, description: "Số lượng Công Huân (Tông môn)" },
                Salary_Info: { type: Type.STRING, description: "Thông tin lương bổng từ chức vụ (VD: 10 linh thạch/tháng)" }
              }
            }
          }
        },
        Long_Term_Goals: { type: Type.ARRAY, items: { type: Type.STRING } },
        World_Variables: {
          type: Type.OBJECT,
          properties: {
            Time_Passed: { type: Type.STRING },
            Current_Location: { type: Type.STRING },
            Current_Weather: { type: Type.STRING },
            Random_Event_Active: { type: Type.STRING },
            In_World_Time: {
              type: Type.OBJECT,
              properties: {
                Current_Day: { type: Type.NUMBER, description: "Ngày hiện tại trong thế giới" },
                Elapsed_Time: { type: Type.STRING, description: "Thời gian đã trôi qua (VD: 3 ngày kể từ khi nhập môn)" },
                Deadline_Status: { type: Type.STRING, description: "Trạng thái các thời hạn quan trọng" },
                Preparation_Level: { type: Type.STRING, description: "Mức độ chuẩn bị của MC cho các sự kiện sắp tới" }
              }
            }
          }
        },
        Global_Context: {
          type: Type.OBJECT,
          properties: {
            Organization_Hierarchy: { type: Type.STRING },
            Entities_Present: { type: Type.ARRAY, items: { type: Type.STRING } },
            Local_Resources: { type: Type.ARRAY, items: { type: Type.STRING } },
            Conceptual_Map: { 
              type: Type.ARRAY, 
              items: {
                type: Type.OBJECT,
                properties: {
                  Location: { type: Type.STRING },
                  Status: { type: Type.STRING, description: "Trạng thái (Đã khám phá, Chưa biết, Đã bị hủy...)" },
                  Description: { type: Type.STRING },
                  Connected_To: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
              },
              description: "Bản đồ các địa điểm người chơi đã biết hoặc đã khám phá" 
            }
          }
        },
        NPC_Tracker: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              Name: { type: Type.STRING },
              Relationship_Status: { type: Type.STRING, description: "Trạng thái quan hệ (VD: Căm hận, Thù địch, Trung lập, Thân thiện, Tích cực, Tri kỷ)" },
              Relationship_Score: { type: Type.NUMBER, description: "Điểm mức độ quan hệ từ -100 (Cực kỳ căm hận) đến 100 (Cực kỳ tích cực)" },
              Hidden_Agenda: { type: Type.STRING }
            }
          }
        },
        Faction_Tracker: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              Name: { type: Type.STRING },
              Reputation: { type: Type.STRING },
              Status: { type: Type.STRING }
            }
          }
        },
        Available_Missions: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              Mission_Name: { type: Type.STRING },
              Difficulty: { type: Type.STRING },
              Reward: { type: Type.STRING },
              Description: { type: Type.STRING }
            }
          }
        },
        Available_Shop_Items: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              Item_Name: { type: Type.STRING },
              Price: { type: Type.STRING },
              Description: { type: Type.STRING }
            }
          }
        },
        Unresolved_Consequences: { type: Type.ARRAY, items: { type: Type.STRING } },
        Logical_Corrections: { type: Type.ARRAY, items: { type: Type.STRING } },
        Invalid_Entities: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Danh sách các tên riêng (NPC, vật phẩm, địa điểm...) bị đánh dấu là spoiler hoặc sai timeline, TUYỆT ĐỐI KHÔNG ĐƯỢC SỬ DỤNG LẠI." },
        Known_Entities: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Danh sách các tên riêng (NPC, vật phẩm, địa điểm...) đã xuất hiện hợp lệ trong truyện." },
        Lorebook: {
          type: Type.OBJECT,
          properties: {
            Cultivation_System: { type: Type.ARRAY, items: { type: Type.STRING } },
            Key_Factions: { type: Type.ARRAY, items: { type: Type.STRING } },
            World_Rules: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        },
        Current_Arc_Summary: { type: Type.STRING }
      }
    }
  }
};

async function generateAndParseJSON(params: any, retries = 3, delay = 2000, timeoutMs = 60000, invalidEntities?: string[]): Promise<any> {
  for (let i = 0; i < retries; i++) {
    try {
      const response = await callGeminiWithRetry(params, 1, delay, timeoutMs);
      let text = "";
      try {
        text = response.text;
      } catch (e) {
        throw new Error("Model response was blocked or empty.");
      }

      if (invalidEntities && invalidEntities.length > 0) {
        const escapeRegExp = (string: string) => {
          return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        };
        invalidEntities.forEach(entity => {
          if (!entity.trim()) return;
          const regex = new RegExp(escapeRegExp(entity), 'gi');
          text = text.replace(regex, '[Thông tin bị ẩn]');
        });
      }

      const parsed = parseJSONResponse(text);
      return { parsed, rawText: text };
    } catch (error: any) {
      const isParsingError = error.message && error.message.includes("parse valid JSON");
      if (isParsingError && i < retries - 1) {
        console.warn(`JSON parsing failed. Retrying... (Attempt ${i + 1}/${retries})`);
        await new Promise(resolve => setTimeout(resolve, delay));
        delay *= 2;
        continue;
      }
      if (i === retries - 1) throw error;
    }
  }
  throw new Error('Failed to generate valid JSON after multiple retries');
}

async function callGeminiWithRetry(params: any, retries = 3, delay = 2000, timeoutMs = 60000) {
  for (let i = 0; i < retries; i++) {
    try {
      // Create a promise that rejects after timeoutMs
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error(`API call timed out after ${timeoutMs}ms`)), timeoutMs);
      });

      // Race the API call against the timeout
      const response = await Promise.race([
        getAIClient().models.generateContent(params),
        timeoutPromise
      ]) as any;
      
      return response;
    } catch (error: any) {
      const errorMsg = typeof error === 'string' ? error : (error?.message || JSON.stringify(error));
      const isSpendingCap = errorMsg.toLowerCase().includes('spending cap');
      const isQuotaError = errorMsg.includes('429') || errorMsg.includes('RESOURCE_EXHAUSTED') || errorMsg.toLowerCase().includes('quota');
      const isTimeout = errorMsg.includes('timed out');
      
      if (isSpendingCap) {
        throw new Error("Tài khoản của bạn đã đạt giới hạn chi tiêu (Spending Cap) trong Google Cloud. Vui lòng bấm nút 'API Key' ở góc trên bên phải để sử dụng API Key của riêng bạn.");
      }

      if (isQuotaError && i === retries - 1) {
        throw new Error("Hết hạn mức sử dụng API (Quota Exceeded). Vui lòng đợi một lát hoặc kiểm tra lại gói dịch vụ của bạn.");
      }

      if ((isQuotaError || isTimeout) && i < retries - 1) {
        // Try to extract retry delay if provided by API
        let waitTime = delay;
        const retryMatch = errorMsg.match(/retry in ([\d.]+)s/);
        if (retryMatch && retryMatch[1]) {
          waitTime = Math.ceil(parseFloat(retryMatch[1]) * 1000) + 500;
        }

        console.warn(`${isTimeout ? 'Timeout' : 'Hết hạn mức'}. Thử lại sau ${waitTime}ms... (Lần ${i + 1}/${retries})`);
        await new Promise(resolve => setTimeout(resolve, waitTime));
        delay *= 2; 
        continue;
      }
      throw error;
    }
  }
  throw new Error('Failed after multiple retries');
}

function parseJSONResponse(text: string): any {
  if (!text) {
    throw new Error("Model returned an empty response.");
  }
  
  // Clean up common issues
  let cleanedText = text.trim();
  
  // Remove markdown code blocks if present
  const jsonMatch = cleanedText.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
  if (jsonMatch && jsonMatch[1]) {
    cleanedText = jsonMatch[1].trim();
  } else {
    // Try to extract just the JSON object or array
    const firstBrace = cleanedText.indexOf('{');
    const lastBrace = cleanedText.lastIndexOf('}');
    const firstBracket = cleanedText.indexOf('[');
    const lastBracket = cleanedText.lastIndexOf(']');
    
    let startIdx = -1;
    let endIdx = -1;

    if (firstBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) {
      startIdx = firstBrace;
      endIdx = lastBrace;
    } else if (firstBracket !== -1) {
      startIdx = firstBracket;
      endIdx = lastBracket;
    }

    if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
      cleanedText = cleanedText.substring(startIdx, endIdx + 1);
    }
  }

  try {
    return JSON.parse(cleanedText);
  } catch (error) {
    console.warn("Failed to parse JSON directly, attempting aggressive cleanup...", error);
    
    try {
      // Fix trailing commas
      cleanedText = cleanedText.replace(/,\s*([\]}])/g, '$1');
      
      // Fix unescaped control characters
      cleanedText = cleanedText.replace(/[\u0000-\u001F]+/g, " ");
      
      return JSON.parse(cleanedText);
    } catch (e) {
      console.error("Raw text that failed to parse:", text);
      throw new Error("Could not parse valid JSON from the model's response.");
    }
  }
}

export async function generateWorldContext(initialText: string) {
  const prompt = `
Bạn là một AI chuyên phân tích bối cảnh tiểu thuyết. Hãy đọc đoạn văn bản mở đầu của câu chuyện sau đây và trích xuất các thông tin cốt lõi để xây dựng Lorebook và Arc Summary.

[VĂN BẢN MỞ ĐẦU]:
${initialText}

Hãy trả về một đối tượng JSON với cấu trúc sau:
{
  "Lorebook": {
    "Cultivation_System": ["Hệ thống tu luyện, các cảnh giới được nhắc đến..."],
    "Key_Factions": ["Các thế lực, tông môn, gia tộc chính..."],
    "World_Rules": ["Các quy luật đặc thù của thế giới này..."],
    "World_Map": [
      {
        "Location_Name": "Tên địa điểm",
        "Description": "Mô tả ngắn gọn",
        "Parent_Location": "Tên địa điểm cha (nếu có)",
        "Sub_Locations": ["Danh sách các địa điểm con (nếu có)"],
        "Importance": "Mức độ quan trọng (Chính, Phụ, Bí cảnh...)"
      }
    ]
  },
  "Current_Arc_Summary": "Tóm tắt ngắn gọn bối cảnh hiện tại: Nhân vật chính là ai, đang ở đâu, sự kiện chính đang diễn ra là gì."
}
  `;

  const config = {
    responseMimeType: "application/json",
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        Lorebook: {
          type: Type.OBJECT,
          properties: {
            Cultivation_System: { type: Type.ARRAY, items: { type: Type.STRING } },
            Key_Factions: { type: Type.ARRAY, items: { type: Type.STRING } },
            World_Rules: { type: Type.ARRAY, items: { type: Type.STRING } },
            World_Map: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  Location_Name: { type: Type.STRING },
                  Description: { type: Type.STRING },
                  Parent_Location: { type: Type.STRING },
                  Sub_Locations: { type: Type.ARRAY, items: { type: Type.STRING } },
                  Importance: { type: Type.STRING }
                }
              }
            }
          }
        },
        Current_Arc_Summary: { type: Type.STRING }
      }
    }
  };

  try {
    const result = await generateAndParseJSON({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config
    }, 2, 2000, 60000);

    return result.parsed;
  } catch (proError) {
    console.warn("Pro model failed for world context, falling back to Flash...", proError);
    try {
      const result = await generateAndParseJSON({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config
      }, 3, 2000, 60000);
      return result.parsed;
    } catch (flashError) {
      console.error("Flash model also failed for world context", flashError);
      return null;
    }
  }
}

export async function startGame(epubContent: string, worldContext?: any) {
  console.log(`Starting game with content length: ${epubContent.length} chars`);
  const startTime = Date.now();
  
  const prompt = `Đây là nội dung và thế giới quan của bộ truyện gốc (có thể đã được rút gọn phần giữa để tối ưu, nhưng vẫn giữ nguyên phần đầu và phần kết thúc):
  
  ${epubContent} 
  
  ${worldContext ? `[LOREBOOK VÀ ARC SUMMARY KHỞI TẠO]:\n${JSON.stringify(worldContext, null, 2)}\n\n` : ''}
  [QUY TẮC ƯU TIÊN]:
  - Hãy lấy bối cảnh, tính cách nhân vật và các mối quan hệ từ nội dung EPUB trên.
  - LƯU Ý QUAN TRỌNG VỀ ĐOẠN TRÍCH: Nội dung được trích xuất để nắm bắt mạch truyện và các cột mốc quan trọng.
  - LƯU Ý QUAN TRỌNG VỀ ĐIỂM KẾT THÚC: Hãy phân tích kỹ phần kết thúc để hiểu được cảnh giới tối cao, trùm cuối, hoặc mục đích tối thượng của thế giới. Từ đó, thiết lập các "Mục Tiêu Dài Hạn" (Long Term Goals) cho người chơi một cách chính xác nhất.
  - TUYỆT ĐỐI ƯU TIÊN các "HỆ THỐNG QUY TẮC CỐT LÕI" đã được định nghĩa trong System Instruction (như Luật Tông Môn, Cơ chế Xác suất, Pacing...) để vận hành trò chơi. 
  - Nếu có sự mâu thuẫn giữa diễn biến truyện gốc và Quy tắc hệ thống, hãy ưu tiên Quy tắc hệ thống để đảm bảo tính công bằng và logic của một trò chơi tương tác.
  
  Hãy bắt đầu chương 1.
  
  [LƯU Ý TỐI QUAN TRỌNG]:
  1. PHẢN HỒI CỦA BẠN BẮT BUỘC PHẢI LÀ MỘT ĐỐI TƯỢNG JSON HỢP LỆ THEO ĐÚNG SCHEMA. KHÔNG ĐƯỢC TRẢ VỀ TEXT THUẦN TÚY.
  2. TUYỆT ĐỐI KHÔNG LẶP LẠI CÂU TỪ. NẾU BẠN THẤY MÌNH ĐANG VIẾT LẶP LẠI MỘT CÂU (VÍ DỤ: "Lựa chọn của bạn là gì?"), HÃY DỪNG LẠI NGAY LẬP TỨC VÀ ĐÓNG KHỐI JSON.
  3. ĐẶC BIỆT LƯU Ý PHẦN 'choices': TUYỆT ĐỐI KHÔNG ĐƯỢC ĐƯA TÊN NHÂN VẬT, ĐỊA ĐIỂM, VẬT PHẨM HAY SỰ KIỆN MỚI VÀO LỰA CHỌN NẾU CHÚNG CHƯA TỪNG XUẤT HIỆN TRONG CÁC DIỄN BIẾN TRƯỚC ĐÓ. CHỈ DÙNG MÔ TẢ CHUNG CHUNG CHO NHỮNG THỨ CHƯA BIẾT TÊN.
  4. BẮT BUỘC điền trường 'continuity_check' trước khi viết 'story' để xác định ai đang có mặt.`;

  try {
    console.log("Calling startGame service with Pro model...");
    const result = await generateAndParseJSON({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: gmResponseSchema,
        temperature: 0.7,
        thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
        maxOutputTokens: 8192,
        safetySettings: [
          { category: "HARM_CATEGORY_HATE_SPEECH" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_HARASSMENT" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_DANGEROUS_CONTENT" as any, threshold: "BLOCK_NONE" as any },
        ],
      },
    }, 2, 2000, 180000); // Increased timeout for thinking

    const endTime = Date.now();
    console.log(`Game started successfully with Pro in ${(endTime - startTime) / 1000}s`);

    return {
      response: result.parsed as GMResponse,
      initialPrompt: prompt
    };
  } catch (proError: any) {
    console.warn("Pro model failed, falling back to Flash model for initialization...", proError);
    
    const result = await generateAndParseJSON({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: gmResponseSchema,
        temperature: 0.6,
        maxOutputTokens: 8192,
        safetySettings: [
          { category: "HARM_CATEGORY_HATE_SPEECH" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_HARASSMENT" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_DANGEROUS_CONTENT" as any, threshold: "BLOCK_NONE" as any },
        ],
      },
    }, 3, 2000, 120000);

    const endTime = Date.now();
    console.log(`Game started successfully with Flash fallback in ${(endTime - startTime) / 1000}s`);

    return {
      response: result.parsed as GMResponse,
      initialPrompt: prompt
    };
  }
}

export async function askMemoryQuery(action: string, history: any[], retrievedContext?: string[], invalidEntities?: string[]) {
  // Fix for old saves where history might start with 'model' instead of 'user'
  let validHistory = [...history];
  if (validHistory.length > 0 && validHistory[0].role === 'model') {
    validHistory.unshift({ role: 'user', parts: [{ text: 'Bắt đầu trò chơi.' }] });
  }

  const branchContextStr = retrieveBranchContext(validHistory);

  let finalActionText = `[MEMORY_QUERY] ${action}`;
  if (retrievedContext && retrievedContext.length > 0) {
    finalActionText = `${branchContextStr}\n\n[TRÍ NHỚ TRUY XUẤT TỪ NGUYÊN TÁC (Đã được lọc theo timeline hiện tại)]:
${retrievedContext.join('\n\n')}

[HÀNH ĐỘNG CỦA NGƯỜI CHƠI]:
[MEMORY_QUERY] ${action}

[LƯU Ý TỐI QUAN TRỌNG]:
1. PHẢN HỒI CỦA BẠN BẮT BUỘC PHẢI LÀ MỘT ĐỐI TƯỢNG JSON HỢP LỆ THEO ĐÚNG SCHEMA. KHÔNG ĐƯỢC TRẢ VỀ TEXT THUẦN TÚY.
2. ĐÂY LÀ TRUY VẤN KÝ ỨC. CHỈ CUNG CẤP THÔNG TIN THUẦN TÚY, KHÔNG ĐẨY TÌNH TIẾT TRUYỆN ĐI TIẾP.
3. RAG CONTEXT BÊN TRÊN CHỈ LÀ THÔNG TIN QUÁ KHỨ/HIỆN TẠI CỦA TRUYỆN GỐC. NẾU KHÔNG CÓ THÔNG TIN VỀ NHÂN VẬT/ĐỊA ĐIỂM, TỨC LÀ NGƯỜI CHƠI CHƯA BIẾT, BẠN KHÔNG ĐƯỢC TỰ BỊA RA TỪ TƯƠNG LAI. BẠN PHẢI GIỮ NGUYÊN CẢNH GIỚI, THỜI GIAN, VÀ TRẠNG THÁI HIỆN TẠI CỦA NHÂN VẬT TRONG GAME. KHÔNG ĐƯỢC NHẢY CÓC CỐT TRUYỆN.
4. ĐẶC BIỆT LƯU Ý PHẦN 'choices': TUYỆT ĐỐI KHÔNG ĐƯỢC ĐƯA TÊN NHÂN VẬT, ĐỊA ĐIỂM, VẬT PHẨM HAY SỰ KIỆN MỚI VÀO LỰA CHỌN NẾU CHÚNG CHƯA TỪNG XUẤT HIỆN TRONG CÁC DIỄN BIẾN TRƯỚC ĐÓ. CHỈ DÙNG MÔ TẢ CHUNG CHUNG CHO NHỮNG THỨ CHƯA BIẾT TÊN.`;
  } else {
    finalActionText = `${branchContextStr}\n\n[HÀNH ĐỘNG CỦA NGƯỜI CHƠI]:
[MEMORY_QUERY] ${action}

[LƯU Ý TỐI QUAN TRỌNG]:
1. PHẢN HỒI CỦA BẠN BẮT BUỘC PHẢI LÀ MỘT ĐỐI TƯỢNG JSON HỢP LỆ THEO ĐÚNG SCHEMA. KHÔNG ĐƯỢC TRẢ VỀ TEXT THUẦN TÚY.
2. ĐÂY LÀ TRUY VẤN KÝ ỨC. CHỈ CUNG CẤP THÔNG TIN THUẦN TÚY, KHÔNG ĐẨY TÌNH TIẾT TRUYỆN ĐI TIẾP.
3. ĐẶC BIỆT LƯU Ý PHẦN 'choices': TUYỆT ĐỐI KHÔNG ĐƯỢC ĐƯA TÊN NHÂN VẬT, ĐỊA ĐIỂM, VẬT PHẨM HAY SỰ KIỆN MỚI VÀO LỰA CHỌN NẾU CHÚNG CHƯA TỪNG XUẤT HIỆN TRONG CÁC DIỄN BIẾN TRƯỚC ĐÓ. CHỈ DÙNG MÔ TẢ CHUNG CHUNG CHO NHỮNG THỨ CHƯA BIẾT TÊN.`;
  }

  if (invalidEntities && invalidEntities.length > 0) {
    finalActionText += `\n\n[QUY TẮC CHỐNG SPOILER]: TUYỆT ĐỐI KHÔNG ĐƯỢC SỬ DỤNG CÁC TÊN RIÊNG SAU TRONG CÂU TRẢ LỜI: ${invalidEntities.join(', ')}. Hãy dùng mô tả chung chung thay thế.`;
  }

  const result = await generateAndParseJSON({
    model: "gemini-3-flash-preview",
    contents: [
      ...validHistory,
      { role: "user", parts: [{ text: finalActionText }] }
    ],
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: gmResponseSchema,
    }
  }, 3, 2000, 60000, invalidEntities);

  let text = result.rawText;
  let parsedResponse = result.parsed as GMResponse;
  
  if (invalidEntities && invalidEntities.length > 0 && parsedResponse && parsedResponse.state) {
    parsedResponse.state.Invalid_Entities = invalidEntities;
  }
  
  return parsedResponse;
}

export interface LibraryCategory {
  category: string;
  subcategories: {
    name: string;
    items: {
      name: string;
      shortDescription: string;
    }[];
  }[];
}

export async function generateLibraryIndex(history: any[], invalidEntities?: string[]): Promise<LibraryCategory[]> {
  let validHistory = [...history];
  if (validHistory.length > 0 && validHistory[0].role === 'model') {
    validHistory.unshift({ role: 'user', parts: [{ text: 'Bắt đầu trò chơi.' }] });
  }

  const branchContextStr = retrieveBranchContext(validHistory);

  let finalActionText = `${branchContextStr}\n\n[HÀNH ĐỘNG CỦA NGƯỜI CHƠI]:
[LIBRARY_INDEX] Hãy liệt kê danh mục các loại đan dược, công pháp, pháp bảo, linh thảo, thế lực... phổ biến hoặc quan trọng trong thế giới này mà nhân vật chính có thể biết. Phân loại rõ ràng (ví dụ: Đan dược -> Hỗ trợ tu vi, Chữa thương...).

[LƯU Ý TỐI QUAN TRỌNG]:
1. PHẢN HỒI CỦA BẠN BẮT BUỘC PHẢI LÀ MỘT MẢNG JSON HỢP LỆ THEO ĐÚNG SCHEMA.
2. Dựa vào bối cảnh truyện hiện tại và kiến thức tu tiên chung để liệt kê những thứ phù hợp nhất. Không được làm lộ cốt truyện tương lai.`;

  if (invalidEntities && invalidEntities.length > 0) {
    finalActionText += `\n\n[QUY TẮC CHỐNG SPOILER]: TUYỆT ĐỐI KHÔNG ĐƯỢC SỬ DỤNG CÁC TÊN RIÊNG SAU TRONG DANH SÁCH: ${invalidEntities.join(', ')}. Hãy dùng mô tả chung chung thay thế.`;
  }

  const result = await generateAndParseJSON({
    model: "gemini-3-flash-preview",
    contents: [
      ...validHistory,
      { role: "user", parts: [{ text: finalActionText }] }
    ],
    config: {
      systemInstruction: "Bạn là một Tàng Kinh Các (Thư viện) của thế giới tu tiên. Nhiệm vụ của bạn là liệt kê danh mục các vật phẩm, khái niệm, công pháp... được phân loại rõ ràng.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING, description: "Ví dụ: Đan dược, Công pháp, Pháp bảo, Linh thảo, Thế lực..." },
            subcategories: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: "Ví dụ: Hỗ trợ tu vi, Chữa thương, Tấn cấp..." },
                  items: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        name: { type: Type.STRING },
                        shortDescription: { type: Type.STRING }
                      },
                      required: ["name", "shortDescription"]
                    }
                  }
                },
                required: ["name", "items"]
              }
            }
          },
          required: ["category", "subcategories"]
        }
      },
    }
  }, 3, 2000, 60000, invalidEntities);

  return result.parsed as LibraryCategory[];
}

export async function askLibraryQuery(query: string, history: any[], retrievedContext?: string[], invalidEntities?: string[]): Promise<{ explanation: string }> {
  let validHistory = [...history];
  if (validHistory.length > 0 && validHistory[0].role === 'model') {
    validHistory.unshift({ role: 'user', parts: [{ text: 'Bắt đầu trò chơi.' }] });
  }

  const branchContextStr = retrieveBranchContext(validHistory);

  let finalActionText = `[LIBRARY_QUERY] Tra cứu thông tin: ${query}`;
  if (retrievedContext && retrievedContext.length > 0) {
    finalActionText = `${branchContextStr}\n\n[TRÍ NHỚ TRUY XUẤT TỪ NGUYÊN TÁC (Đã được lọc theo timeline hiện tại)]:
${retrievedContext.join('\n\n')}

[HÀNH ĐỘNG CỦA NGƯỜI CHƠI]:
[LIBRARY_QUERY] Tra cứu thông tin: ${query}

[LƯU Ý TỐI QUAN TRỌNG]:
1. PHẢN HỒI CỦA BẠN BẮT BUỘC PHẢI LÀ MỘT ĐỐI TƯỢNG JSON HỢP LỆ VỚI TRƯỜNG 'explanation'.
2. ĐÂY LÀ TRUY VẤN THƯ VIỆN. CHỈ CUNG CẤP THÔNG TIN KIẾN THỨC VỀ VẬT PHẨM, LINH DƯỢC, THẢO MỘC, CÔNG PHÁP, HOẶC KHÁI NIỆM ĐƯỢC HỎI.
3. RAG CONTEXT BÊN TRÊN CHỈ LÀ THÔNG TIN QUÁ KHỨ/HIỆN TẠI CỦA TRUYỆN GỐC. NẾU KHÔNG CÓ THÔNG TIN, HÃY DỰA VÀO LORE CHUNG CỦA THẾ GIỚI TU TIÊN NHƯNG KHÔNG ĐƯỢC LÀM LỘ CỐT TRUYỆN TƯƠNG LAI.`;
  } else {
    finalActionText = `${branchContextStr}\n\n[HÀNH ĐỘNG CỦA NGƯỜI CHƠI]:
[LIBRARY_QUERY] Tra cứu thông tin: ${query}

[LƯU Ý TỐI QUAN TRỌNG]:
1. PHẢN HỒI CỦA BẠN BẮT BUỘC PHẢI LÀ MỘT ĐỐI TƯỢNG JSON HỢP LỆ VỚI TRƯỜNG 'explanation'.
2. ĐÂY LÀ TRUY VẤN THƯ VIỆN. CHỈ CUNG CẤP THÔNG TIN KIẾN THỨC VỀ VẬT PHẨM, LINH DƯỢC, THẢO MỘC, CÔNG PHÁP, HOẶC KHÁI NIỆM ĐƯỢC HỎI. DỰA VÀO LORE CHUNG CỦA THẾ GIỚI TU TIÊN.`;
  }

  if (invalidEntities && invalidEntities.length > 0) {
    finalActionText += `\n\n[QUY TẮC CHỐNG SPOILER]: TUYỆT ĐỐI KHÔNG ĐƯỢC SỬ DỤNG CÁC TÊN RIÊNG SAU TRONG CÂU TRẢ LỜI: ${invalidEntities.join(', ')}. Hãy dùng mô tả chung chung thay thế.`;
  }

  const result = await generateAndParseJSON({
    model: "gemini-3-flash-preview",
    contents: [
      ...validHistory,
      { role: "user", parts: [{ text: finalActionText }] }
    ],
    config: {
      systemInstruction: "Bạn là một Tàng Kinh Các (Thư viện) của thế giới tu tiên. Nhiệm vụ của bạn là giải thích chi tiết công dụng, nguồn gốc, và cách dùng của các loại linh dược, thảo mộc, vật phẩm, công pháp... dựa trên bối cảnh truyện hoặc kiến thức tu tiên chung.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          explanation: {
            type: Type.STRING,
            description: "Giải thích chi tiết về vật phẩm/khái niệm được tra cứu (công dụng, cách dùng, nguồn gốc...)"
          }
        },
        required: ["explanation"]
      },
    }
  }, 3, 2000, 60000, invalidEntities);

  return result.parsed as { explanation: string };
}

export function scrubCanonState(history: any[], currentResponse: GMResponse | null, invalidEntities: string[]): { scrubbedHistory: any[], scrubbedResponse: GMResponse | null } {
  if (!invalidEntities || invalidEntities.length === 0) {
    return { scrubbedHistory: history, scrubbedResponse: currentResponse };
  }

  const escapeRegExp = (string: string) => {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  };

  const scrubText = (text: string) => {
    if (!text) return text;
    let newText = text;
    invalidEntities.forEach(entity => {
      if (!entity.trim()) return;
      const regex = new RegExp(escapeRegExp(entity), 'gi');
      newText = newText.replace(regex, '[Thông tin bị ẩn]');
    });
    return newText;
  };

  const scrubbedHistory = history.map(h => {
    if (h.role === 'model') {
      try {
        const parsed = JSON.parse(h.parts[0].text);
        const jsonString = JSON.stringify(parsed);
        const scrubbedJsonString = scrubText(jsonString);
        const scrubbedParsed = JSON.parse(scrubbedJsonString);
        if (scrubbedParsed && scrubbedParsed.state) {
          scrubbedParsed.state.Invalid_Entities = invalidEntities;
        }
        return { ...h, parts: [{ text: JSON.stringify(scrubbedParsed) }] };
      } catch (e) {
        return { ...h, parts: [{ text: scrubText(h.parts[0].text) }] };
      }
    } else {
      return { ...h, parts: [{ text: scrubText(h.parts[0].text) }] };
    }
  });

  let scrubbedResponse = currentResponse;
  if (currentResponse) {
    const jsonString = JSON.stringify(currentResponse);
    const scrubbedJsonString = scrubText(jsonString);
    try {
      scrubbedResponse = JSON.parse(scrubbedJsonString);
      if (scrubbedResponse && scrubbedResponse.state) {
        scrubbedResponse.state.Invalid_Entities = invalidEntities;
      }
    } catch (e) {
      console.error("Failed to parse scrubbed response", e);
    }
  }

  return { scrubbedHistory, scrubbedResponse };
}

export function retrieveBranchContext(history: any[]): string {
  let currentState = null;
  for (let i = history.length - 1; i >= 0; i--) {
    if (history[i].role === 'model') {
      try {
        const parsed = JSON.parse(history[i].parts[0].text);
        if (parsed && parsed.state) {
          currentState = parsed.state;
          break;
        }
      } catch (e) {
        // Ignore parse errors
      }
    }
  }

  if (!currentState) return '';

  let branchContext = `[BRANCH CONTEXT - TRẠNG THÁI HIỆN TẠI CỦA NHÁNH TRUYỆN NÀY]\n`;
  branchContext += `Đây là trạng thái HIỆN TẠI của người chơi. BẠN BẮT BUỘC PHẢI DỰA VÀO ĐÂY ĐỂ ĐƯA RA LỰA CHỌN VÀ DIỄN BIẾN TIẾP THEO:\n\n`;

  if (currentState.World_Variables) {
    branchContext += `- Thời gian & Địa điểm:\n`;
    branchContext += `  + Địa điểm hiện tại: ${currentState.World_Variables.Current_Location || 'Không rõ'}\n`;
    if (currentState.World_Variables.In_World_Time) {
      branchContext += `  + Ngày: ${currentState.World_Variables.In_World_Time.Current_Day || 'Không rõ'}, Thời gian trôi qua: ${currentState.World_Variables.In_World_Time.Elapsed_Time || 'Không rõ'}\n`;
      branchContext += `  + Thời hạn (Deadline): ${currentState.World_Variables.In_World_Time.Deadline_Status || 'Không rõ'}\n`;
    }
  }

  if (currentState.MC_Status) {
    branchContext += `- Trạng thái Nhân vật chính:\n`;
    branchContext += `  + Cảnh giới/Level: ${currentState.MC_Status.Level || 'Không rõ'}\n`;
    branchContext += `  + HP: ${currentState.MC_Status.HP_Current}/${currentState.MC_Status.HP_Max}\n`;
    branchContext += `  + Năng lượng (${currentState.MC_Status.Resource_Label || 'Năng lượng'}): ${currentState.MC_Status.Resource_Current}/${currentState.MC_Status.Resource_Max}\n`;
    branchContext += `  + Túi đồ (Inventory): ${currentState.MC_Status.Inventory || 'Trống'}\n`;
    if (currentState.MC_Status.Wealth) {
      branchContext += `  + Tài sản: Linh Thạch: ${currentState.MC_Status.Wealth.Spirit_Stones}, Công Huân: ${currentState.MC_Status.Wealth.Merit_Points}, Lương: ${currentState.MC_Status.Wealth.Salary_Info}\n`;
    }
  }

  if (currentState.Global_Context && currentState.Global_Context.Conceptual_Map) {
    const map = currentState.Global_Context.Conceptual_Map;
    if (Array.isArray(map)) {
      branchContext += `- Bản đồ đã khám phá (Explored Map):\n`;
      map.forEach((loc: any) => {
        branchContext += `  + ${loc.Location} (${loc.Status}): ${loc.Description}. Kết nối: ${loc.Connected_To?.join(', ') || 'Không'}\n`;
      });
    } else {
      branchContext += `- Bản đồ khái niệm (Map Knowledge): ${map}\n`;
    }
  }

  if (currentState.Long_Term_Goals && currentState.Long_Term_Goals.length > 0) {
    branchContext += `- Mục tiêu/Nhiệm vụ hiện tại (Active Quests): ${currentState.Long_Term_Goals.join(', ')}\n`;
  }

  if (currentState.Known_Entities && currentState.Known_Entities.length > 0) {
    branchContext += `- Thực thể đã biết (Known Entities): ${currentState.Known_Entities.join(', ')}\n`;
  }

  if (currentState.Unresolved_Consequences && currentState.Unresolved_Consequences.length > 0) {
    branchContext += `- Hậu quả chưa giải quyết (Unresolved Consequences): ${currentState.Unresolved_Consequences.join(', ')}\n`;
  }

  if (currentState.Current_Arc_Summary) {
    branchContext += `- Tóm tắt Arc hiện tại (Current Arc Summary): ${currentState.Current_Arc_Summary}\n`;
  }

  return branchContext;
}

export async function sendAction(action: string, history: any[], retrievedContext?: string[], invalidEntities?: string[]) {
  const startTime = Date.now();
  
  // Fix for old saves where history might start with 'model' instead of 'user'
  let validHistory = [...history];
  if (validHistory.length > 0 && validHistory[0].role === 'model') {
    validHistory.unshift({ role: 'user', parts: [{ text: 'Bắt đầu trò chơi.' }] });
  }

  const branchContextStr = retrieveBranchContext(validHistory);

  let finalActionText = action;
  if (retrievedContext && retrievedContext.length > 0) {
    finalActionText = `${branchContextStr}\n\n[TRÍ NHỚ TRUY XUẤT TỪ NGUYÊN TÁC (Đã được lọc theo timeline hiện tại)]:
${retrievedContext.join('\n\n')}

[HÀNH ĐỘNG CỦA NGƯỜI CHƠI]:
${action}

[LƯU Ý TỐI QUAN TRỌNG]:
- PHẢN HỒI CỦA BẠN BẮT BUỘC PHẢI LÀ MỘT ĐỐI TƯỢNG JSON HỢP LỆ THEO ĐÚNG SCHEMA. KHÔNG ĐƯỢC TRẢ VỀ TEXT THUẦN TÚY.
- TUYỆT ĐỐI KHÔNG LẶP LẠI CÂU TỪ. NẾU BẠN THẤY MÌNH ĐANG VIẾT LẶP LẠI MỘT CÂU, HÃY DỪNG LẠI NGAY LẬP TỨC VÀ ĐÓNG KHỐI JSON.
- RAG CONTEXT BÊN TRÊN CHỈ LÀ THÔNG TIN QUÁ KHỨ/HIỆN TẠI CỦA TRUYỆN GỐC. NẾU KHÔNG CÓ THÔNG TIN VỀ NHÂN VẬT/ĐỊA ĐIỂM, TỨC LÀ NGƯỜI CHƠI CHƯA BIẾT, BẠN KHÔNG ĐƯỢC TỰ BỊA RA TỪ TƯƠNG LAI. BẠN PHẢI GIỮ NGUYÊN CẢNH GIỚI, THỜI GIAN, VÀ TRẠNG THÁI HIỆN TẠI CỦA NHÂN VẬT TRONG GAME. KHÔNG ĐƯỢC NHẢY CÓC CỐT TRUYỆN.
- ĐẶC BIỆT LƯU Ý PHẦN 'choices': TUYỆT ĐỐI KHÔNG ĐƯỢC ĐƯA TÊN NHÂN VẬT, ĐỊA ĐIỂM, VẬT PHẨM HAY SỰ KIỆN MỚI VÀO LỰA CHỌN NẾU CHÚNG CHƯA TỪNG XUẤT HIỆN TRONG CÁC DIỄN BIẾN TRƯỚC ĐÓ. CHỈ DÙNG MÔ TẢ CHUNG CHUNG CHO NHỮNG THỨ CHƯA BIẾT TÊN.
- TÍNH LIÊN TỤC CỦA NHÂN VẬT: Hãy kiểm tra kỹ 'NPC_Tracker' và 'Entities_Present'. Tuyệt đối KHÔNG miêu tả một nhân vật đang có mặt nếu họ đã rời đi, bị bắt, hoặc chết ở các diễn biến trước. Cập nhật trạng thái của họ cho đúng. BẮT BUỘC điền trường 'continuity_check' trước khi viết 'story'.`;
  } else {
    finalActionText = `${branchContextStr}\n\n[HÀNH ĐỘNG CỦA NGƯỜI CHƠI]:
${action}

[LƯU Ý TỐI QUAN TRỌNG]:
- PHẢN HỒI CỦA BẠN BẮT BUỘC PHẢI LÀ MỘT ĐỐI TƯỢNG JSON HỢP LỆ THEO ĐÚNG SCHEMA. KHÔNG ĐƯỢC TRẢ VỀ TEXT THUẦN TÚY.
- TUYỆT ĐỐI KHÔNG LẶP LẠI CÂU TỪ. NẾU BẠN THẤY MÌNH ĐANG VIẾT LẶP LẠI MỘT CÂU, HÃY DỪNG LẠI NGAY LẬP TỨC VÀ ĐÓNG KHỐI JSON.
- ĐẶC BIỆT LƯU Ý PHẦN 'choices': TUYỆT ĐỐI KHÔNG ĐƯỢC ĐƯA TÊN NHÂN VẬT, ĐỊA ĐIỂM, VẬT PHẨM HAY SỰ KIỆN MỚI VÀO LỰA CHỌN NẾU CHÚNG CHƯA TỪNG XUẤT HIỆN TRONG CÁC DIỄN BIẾN TRƯỚC ĐÓ. CHỈ DÙNG MÔ TẢ CHUNG CHUNG CHO NHỮNG THỨ CHƯA BIẾT TÊN.
- TÍNH LIÊN TỤC CỦA NHÂN VẬT: Hãy kiểm tra kỹ 'NPC_Tracker' và 'Entities_Present'. Tuyệt đối KHÔNG miêu tả một nhân vật đang có mặt nếu họ đã rời đi, bị bắt, hoặc chết ở các diễn biến trước. Cập nhật trạng thái của họ cho đúng. BẮT BUỘC điền trường 'continuity_check' trước khi viết 'story'.`;
  }

  if (invalidEntities && invalidEntities.length > 0) {
    finalActionText += `\n- [QUY TẮC CHỐNG SPOILER]: TUYỆT ĐỐI KHÔNG ĐƯỢC SỬ DỤNG CÁC TÊN RIÊNG SAU TRONG CỐT TRUYỆN HOẶC LỰA CHỌN: ${invalidEntities.join(', ')}. Hãy dùng mô tả chung chung thay thế.`;
  }

  try {
    const result = await generateAndParseJSON({
      model: "gemini-3.1-pro-preview",
      contents: [
        ...validHistory,
        { role: "user", parts: [{ text: finalActionText }] }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: gmResponseSchema,
        temperature: 0.8,
        thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
        maxOutputTokens: 8192,
        safetySettings: [
          { category: "HARM_CATEGORY_HATE_SPEECH" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_HARASSMENT" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_DANGEROUS_CONTENT" as any, threshold: "BLOCK_NONE" as any },
        ],
      },
    }, 2, 2000, 180000, invalidEntities);

    const endTime = Date.now();
    console.log(`Action processed with Pro in ${(endTime - startTime) / 1000}s`);

    let parsedResponse = result.parsed as GMResponse;
    if (invalidEntities && invalidEntities.length > 0 && parsedResponse && parsedResponse.state) {
      parsedResponse.state.Invalid_Entities = invalidEntities;
    }
    return parsedResponse;
  } catch (error) {
    console.warn("Pro model failed for action, falling back to Flash...", error);
    const result = await generateAndParseJSON({
      model: "gemini-3-flash-preview",
      contents: [
        ...validHistory,
        { role: "user", parts: [{ text: finalActionText }] }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: gmResponseSchema,
        temperature: 0.7,
        maxOutputTokens: 8192,
        safetySettings: [
          { category: "HARM_CATEGORY_HATE_SPEECH" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_HARASSMENT" as any, threshold: "BLOCK_NONE" as any },
          { category: "HARM_CATEGORY_DANGEROUS_CONTENT" as any, threshold: "BLOCK_NONE" as any },
        ],
      },
    }, 3, 2000, 120000, invalidEntities);

    const endTime = Date.now();
    console.log(`Action processed with Flash fallback in ${(endTime - startTime) / 1000}s`);

    let parsedResponse = result.parsed as GMResponse;
    if (invalidEntities && invalidEntities.length > 0 && parsedResponse && parsedResponse.state) {
      parsedResponse.state.Invalid_Entities = invalidEntities;
    }
    return parsedResponse;
  }
}

export async function generateMapImage(location: string, context: string): Promise<string | null> {
  const prompt = `A detailed fantasy RPG map of ${location}. Top-down view, parchment style, clear terrain features, landmarks, immersive. Context: ${context.substring(0, 500)}`;
  
  try {
    const response = await getAIClient().models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }]
      }
    });
    
    const parts = response.candidates?.[0]?.content?.parts || [];
    for (const part of parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating map:", error);
    return null;
  }
}
