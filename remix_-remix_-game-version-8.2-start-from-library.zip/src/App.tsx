import React, { useState, useEffect, useRef } from 'react';
import { get } from 'idb-keyval';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { Send, Terminal, RefreshCcw, BookOpen, ChevronRight, Download, Upload, Plus, Trash2, Save, RotateCcw, History, Map, Loader2, X, Brain, List, Activity, Key } from 'lucide-react';
import { startGame, sendAction, askMemoryQuery, askLibraryQuery, generateLibraryIndex, LibraryCategory, generateMapImage, generateWorldContext, GMResponse, GameState, scrubCanonState } from './services/geminiService';
import { processAndIndexText, retrieveContext, saveChunksToDB, loadChunksFromDB, deleteChunksFromDB, getChunks, loadChunks } from './services/ragService';
import EpubUploader from './components/EpubUploader';
import { parseEpubFile } from './utils/epubParser';
import StatusBoard from './components/StatusBoard';
import { saveWorldToLocalDB, loadWorldsFromLocalDB, deleteWorldFromLocalDB } from './services/localDB';

export interface WorldSave {
  id: string;
  name: string;
  currentResponse: GMResponse;
  history: any[];
  timestamp: number;
  correctionNotes?: string[];
  invalidEntities?: string[];
  ragChunks?: any[];
}

export default function App() {
  const [gameStarted, setGameStarted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const [currentResponse, setCurrentResponse] = useState<GMResponse | null>(null);
  const [userInput, setUserInput] = useState('');
  const [worlds, setWorlds] = useState<WorldSave[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [activeWorldId, setActiveWorldId] = useState<string | null>(null);
  const [showNameModal, setShowNameModal] = useState(false);
  const [showRestartModal, setShowRestartModal] = useState(false);
  const [worldToDelete, setWorldToDelete] = useState<string | null>(null);
  const [notification, setNotification] = useState<{message: string, type: 'error' | 'success'} | null>(null);
  const [pendingContent, setPendingContent] = useState<string | null>(null);
  const [newWorldName, setNewWorldName] = useState('');
  const [mapImage, setMapImage] = useState<string | null>(null);
  const [isGeneratingMap, setIsGeneratingMap] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  const [showMigrationModal, setShowMigrationModal] = useState(false);
  const [showBackupReminder, setShowBackupReminder] = useState(false);
  const [lastBackupReminderTurn, setLastBackupReminderTurn] = useState(0);
  const [migrationJsonFile, setMigrationJsonFile] = useState<File | null>(null);
  const [migrationEpubFile, setMigrationEpubFile] = useState<File | null>(null);
  const [isMigrating, setIsMigrating] = useState(false);
  const [migrationProgress, setMigrationProgress] = useState('');
  const [leftSidebarTab, setLeftSidebarTab] = useState<'status' | 'history' | 'library'>('status');
  const [libraryQuery, setLibraryQuery] = useState('');
  const [libraryResponse, setLibraryResponse] = useState<string | null>(null);
  const [isLibraryLoading, setIsLibraryLoading] = useState(false);
  const [libraryIndex, setLibraryIndex] = useState<LibraryCategory[] | null>(null);
  const [isGeneratingIndex, setIsGeneratingIndex] = useState(false);
  const [isMemoryMode, setIsMemoryMode] = useState(false);
  const [memoryQueryResponse, setMemoryQueryResponse] = useState<GMResponse | null>(null);
  const [lastMemoryQuery, setLastMemoryQuery] = useState('');
  const [showMobileStats, setShowMobileStats] = useState(false);
  const [showMobileLibrary, setShowMobileLibrary] = useState(false);
  const [showSkillMenu, setShowSkillMenu] = useState(false);
  const [loadingTime, setLoadingTime] = useState(0);
  const [loadingMessage, setLoadingMessage] = useState('GM ĐANG KHỞI TẠO THẾ GIỚI...');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Timer for loading state
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (loading) {
      setLoadingTime(0);
      interval = setInterval(() => {
        setLoadingTime(prev => {
          const newTime = prev + 1;
          if (!gameStarted) {
            if (newTime > 120) {
              setLoadingMessage('THẾ GIỚI QUÁ RỘNG LỚN, GM ĐANG CỐ GẮNG HOÀN THIỆN...');
            } else if (newTime > 60) {
              setLoadingMessage('ĐANG XÂY DỰNG NHÂN QUẢ VÀ LOGIC TRUYỆN...');
            } else if (newTime > 30) {
              setLoadingMessage('ĐANG PHÂN TÍCH HỆ THỐNG CẢNH GIỚI VÀ NHÂN VẬT...');
            } else {
              setLoadingMessage('GM ĐANG KHỞI TẠO THẾ GIỚI...');
            }
          } else {
            if (newTime > 30) {
              setLoadingMessage('GM ĐANG TÍNH TOÁN HỆ QUẢ PHỨC TẠP...');
            } else if (newTime > 15) {
              setLoadingMessage('ĐANG CẬP NHẬT TRẠNG THÁI NHÂN VẬT...');
            } else {
              setLoadingMessage('GM ĐANG SUY TÍNH...');
            }
          }
          return newTime;
        });
      }, 1000);
    } else {
      setLoadingTime(0);
      setLoadingMessage(gameStarted ? 'GM ĐANG SUY TÍNH...' : 'GM ĐANG KHỞI TẠO THẾ GIỚI...');
    }
    return () => clearInterval(interval);
  }, [loading, gameStarted]);

  // Auto-hide notifications
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // Backup reminder effect
  useEffect(() => {
    if (!gameStarted || !history) return;
    const modelTurns = history.filter(h => h.role === 'model').length;
    if (modelTurns > 0 && modelTurns % 15 === 0 && modelTurns !== lastBackupReminderTurn) {
      setShowBackupReminder(true);
      setLastBackupReminderTurn(modelTurns);
    }
  }, [history, gameStarted, lastBackupReminderTurn]);

  // Fetch worlds from local DB on mount
  useEffect(() => {
    const loadWorlds = async () => {
      const fetchedWorlds = await loadWorldsFromLocalDB();
      setWorlds(fetchedWorlds);
    };
    loadWorlds();
  }, []);

  const syncWorldToLocal = async (world: WorldSave) => {
    setIsSyncing(true);
    try {
      await saveWorldToLocalDB(world);
    } catch (error) {
      console.error("Failed to save world to local DB", error);
    } finally {
      setIsSyncing(false);
    }
  };

  const saveCurrentWorld = (resp: GMResponse, hist: any[]) => {
    if (!activeWorldId) return;
    
    const updatedWorld = worlds.find(w => w.id === activeWorldId);
    if (!updatedWorld) return;

    const newWorldData = { ...updatedWorld, currentResponse: resp, history: hist, timestamp: Date.now() };
    
    setWorlds(prev => prev.map(w => 
      w.id === activeWorldId ? newWorldData : w
    ));

    syncWorldToLocal(newWorldData);
  };

  const createNewWorld = async (name: string, resp: GMResponse, hist: any[], correctionNotes: string[] = [], invalidEntities: string[] = []) => {
    const newId = typeof crypto.randomUUID === 'function' 
      ? crypto.randomUUID() 
      : Date.now().toString(36) + Math.random().toString(36).substring(2);
      
    const newWorld: WorldSave = {
      id: newId,
      name: name || `Thế giới ${worlds.length + 1}`,
      currentResponse: resp,
      history: hist,
      timestamp: Date.now(),
      correctionNotes,
      invalidEntities
    };
    
    await saveChunksToDB(newId);
    
    console.log("Creating new world:", newWorld);
    setWorlds(prev => [newWorld, ...prev]);
    setActiveWorldId(newWorld.id);
    setCurrentResponse(resp);
    setHistory(hist);
    setGameStarted(true);
    syncWorldToLocal(newWorld);
  };

  const deleteWorld = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setWorldToDelete(id);
  };

  const confirmDeleteWorld = async () => {
    if (!worldToDelete) return;
    try {
      await deleteWorldFromLocalDB(worldToDelete);
      await deleteChunksFromDB(worldToDelete);
      
      setWorlds(prev => prev.filter(w => w.id !== worldToDelete));
      if (activeWorldId === worldToDelete) {
        setGameStarted(false);
        setActiveWorldId(null);
      }
      setWorldToDelete(null);
      setNotification({ message: 'Đã xóa thế giới.', type: 'success' });
    } catch (error) {
      console.error("Failed to delete world", error);
    }
  };

  const confirmRestartWorld = () => {
    console.log("Attempting to restart world. History length:", history.length);
    if (loading || history.length < 2) {
      console.warn("Cannot restart: loading or history too short");
      setShowRestartModal(false);
      return;
    }
    
    // Find the first model response in history (usually at index 1)
    const firstModelIdx = history.findIndex(h => h.role === 'model');
    console.log("First model response index:", firstModelIdx);
    
    if (firstModelIdx !== -1) {
      const initialHistory = history.slice(0, firstModelIdx + 1);
      try {
        const firstResponseText = initialHistory[firstModelIdx].parts[0].text;
        const parsedResponse = JSON.parse(firstResponseText);
        
        console.log("Restarting with initial response:", parsedResponse);
        
        setHistory(initialHistory);
        setCurrentResponse(parsedResponse);
        
        // Force update worlds array
        if (activeWorldId) {
          const updatedWorld = { 
            ...worlds.find(w => w.id === activeWorldId)!, 
            currentResponse: parsedResponse, 
            history: initialHistory, 
            timestamp: Date.now() 
          };
          setWorlds(prev => prev.map(w => 
            w.id === activeWorldId ? updatedWorld : w
          ));
          syncWorldToLocal(updatedWorld);
        }
        
        setNotification({ message: 'Thế giới đã được khởi động lại từ đầu.', type: 'success' });
      } catch (e) {
        console.error("Failed to parse initial response during restart:", e);
        setNotification({ message: 'Lỗi: Không thể khôi phục trạng thái ban đầu.', type: 'error' });
      }
    } else {
      console.error("No model response found in history to restart from");
      setNotification({ message: 'Không tìm thấy điểm bắt đầu để khởi động lại.', type: 'error' });
    }
    setShowRestartModal(false);
  };

  const exportWorld = async (world: WorldSave, e: React.MouseEvent) => {
    e.stopPropagation();
    
    let worldToExport = { ...world };
    if (world.id === activeWorldId) {
      worldToExport.ragChunks = getChunks();
    } else {
      // Fetch chunks from local DB for inactive worlds
      try {
        const savedChunks = await get(`rag_chunks_${world.id}`);
        if (savedChunks) {
          worldToExport.ragChunks = savedChunks;
        }
      } catch (err) {
        console.error("Failed to load chunks for export", err);
      }
    }
    
    const dataStr = JSON.stringify(worldToExport, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `${world.name.replace(/\s+/g, '_')}_save.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const importedWorld = JSON.parse(event.target?.result as string) as WorldSave;
        
        // --- MIGRATION LOGIC FOR OLDER SAVES ---
        // Ensure it has a unique ID to avoid collisions
        importedWorld.id = typeof crypto.randomUUID === 'function' 
          ? crypto.randomUUID() 
          : Date.now().toString(36) + Math.random().toString(36).substring(2);
        
        // Ensure timestamp exists
        if (!importedWorld.timestamp) {
          importedWorld.timestamp = Date.now();
        }

        // Ensure currentResponse and state exist
        if (!importedWorld.currentResponse) {
          throw new Error("Invalid save file: missing currentResponse");
        }
        
        if (!importedWorld.currentResponse.state) {
          importedWorld.currentResponse.state = {} as any;
        }

        const state = importedWorld.currentResponse.state;

        // Fill in missing state fields from older versions
        if (!state.Game_Status) state.Game_Status = "Đang diễn ra";
        if (!state.Pacing_State) state.Pacing_State = "DOWNTIME";
        
        if (!state.Dice_Roll_Log) {
          state.Dice_Roll_Log = {
            Action_Attempted: "N/A",
            Base_Roll: "N/A",
            Modifiers: "N/A",
            Final_Score: "N/A",
            Result_Logic: "N/A"
          };
        }

        if (!state.MC_Status) {
          state.MC_Status = { 
            HP_Current: 100, 
            HP_Max: 100, 
            Resource_Label: "Năng lượng", 
            Resource_Current: 100, 
            Resource_Max: 100, 
            Level: "Phàm Nhân", 
            Skills: [], 
            Skill_Mastery: [],
            Inventory: "Trống",
            Wealth: {
              Spirit_Stones: 0,
              Merit_Points: 0,
              Salary_Info: "Chưa có"
            }
          };
        } else if (!state.MC_Status.Wealth) {
          state.MC_Status.Wealth = {
            Spirit_Stones: 0,
            Merit_Points: 0,
            Salary_Info: "Chưa có"
          };
        }

        if (!state.Long_Term_Goals) state.Long_Term_Goals = [];
        if (!state.Available_Missions) state.Available_Missions = [];
        if (!state.Available_Shop_Items) state.Available_Shop_Items = [];
        
        if (!state.World_Variables) {
          state.World_Variables = {
            Time_Passed: "0 ngày",
            Current_Location: "Không rõ",
            Current_Weather: "Bình thường",
            Random_Event_Active: "None",
            In_World_Time: {
              Current_Day: 1,
              Elapsed_Time: "0 ngày",
              Deadline_Status: "Chưa có",
              Preparation_Level: "Sơ cấp"
            }
          };
        }

        if (!state.Global_Context) {
          state.Global_Context = {
            Organization_Hierarchy: "Không rõ",
            Entities_Present: [],
            Local_Resources: [],
            Conceptual_Map: "Không rõ"
          };
        }

        if (!state.NPC_Tracker) state.NPC_Tracker = [];
        if (!state.Faction_Tracker) state.Faction_Tracker = [];
        if (!importedWorld.invalidEntities) importedWorld.invalidEntities = [];
        if (!state.Unresolved_Consequences) state.Unresolved_Consequences = [];
        if (!state.Logical_Corrections) state.Logical_Corrections = [];
        
        // --- END MIGRATION LOGIC ---

        if (importedWorld.ragChunks && importedWorld.ragChunks.length > 0) {
          loadChunks(importedWorld.ragChunks);
          await saveChunksToDB(importedWorld.id);
        }

        const worldToSave = { ...importedWorld };
        delete worldToSave.ragChunks;

        setWorlds(prev => [worldToSave, ...prev]);
        syncWorldToLocal(worldToSave);
        setNotification({ message: `Đã nhập và đồng bộ thành công thế giới: ${worldToSave.name}`, type: 'success' });
      } catch (err) {
        console.error("Import error:", err);
        setNotification({ message: 'File không hợp lệ hoặc bị lỗi định dạng.', type: 'error' });
      }
    };
    reader.readAsText(file);
  };

  const handleMigration = async () => {
    if (!migrationJsonFile || !migrationEpubFile) {
      setNotification({ message: 'Vui lòng chọn cả file JSON và EPUB.', type: 'error' });
      return;
    }
    
    setIsMigrating(true);
    try {
      // 1. Read JSON
      setMigrationProgress('Đang đọc file save cũ...');
      const jsonText = await migrationJsonFile.text();
      const importedWorld = JSON.parse(jsonText) as WorldSave;
      
      // 2. Read EPUB
      setMigrationProgress('Đang phân tích EPUB mới...');
      const arrayBuffer = await migrationEpubFile.arrayBuffer();
      const epubText = await parseEpubFile(arrayBuffer, setMigrationProgress);
      
      // 3. Process and Index Text
      setMigrationProgress('Đang lập chỉ mục dữ liệu (RAG)...');
      processAndIndexText(epubText);
      
      // 4. Generate World Context
      setMigrationProgress('Đang trích xuất Lorebook & Arc Summary...');
      const initialText = epubText.substring(0, 40000);
      const worldContext = await generateWorldContext(initialText);
      
      // 5. Update History
      setMigrationProgress('Đang cập nhật lịch sử...');
      if (importedWorld.history && importedWorld.history.length > 0) {
        const firstUserPromptIndex = importedWorld.history.findIndex(h => h.role === 'user');
        if (firstUserPromptIndex !== -1) {
          const newPrompt = `Đây là toàn bộ nội dung và thế giới quan của bộ truyện gốc (bao gồm phần đầu, đoạn trích giữa và phần kết thúc):
  
  ${epubText} 
  
  ${worldContext ? `[LOREBOOK VÀ ARC SUMMARY KHỞI TẠO]:\n${JSON.stringify(worldContext, null, 2)}\n\n` : ''}
  [QUY TẮC ƯU TIÊN]:
  - Hãy lấy bối cảnh, tính cách nhân vật và các mối quan hệ từ nội dung EPUB trên.
  - LƯU Ý QUAN TRỌNG VỀ ĐOẠN TRÍCH: Nội dung được trích xuất từ 3 phần (Đầu, Giữa, Cuối) để nắm bắt toàn bộ mạch truyện và các cột mốc quan trọng.
  - LƯU Ý QUAN TRỌNG VỀ ĐIỂM KẾT THÚC: Hãy phân tích kỹ phần kết thúc để hiểu được cảnh giới tối cao, trùm cuối, hoặc mục đích tối thượng của thế giới. Từ đó, thiết lập các "Mục Tiêu Dài Hạn" (Long Term Goals) cho người chơi một cách chính xác nhất.
  - TUYỆT ĐỐI ƯU TIÊN các "HỆ THỐNG QUY TẮC CỐT LÕI" đã được định nghĩa trong System Instruction (như Luật Tông Môn, Cơ chế Xác suất, Pacing...) để vận hành trò chơi. 
  - Nếu có sự mâu thuẫn giữa diễn biến truyện gốc và Quy tắc hệ thống, hãy ưu tiên Quy tắc hệ thống để đảm bảo tính công bằng và logic của một trò chơi tương tác.
  
  Hãy bắt đầu chương 1.
  
  [LƯU Ý TỐI QUAN TRỌNG]:
  1. PHẢN HỒI CỦA BẠN BẮT BUỘC PHẢI LÀ MỘT ĐỐI TƯỢNG JSON HỢP LỆ THEO ĐÚNG SCHEMA. KHÔNG ĐƯỢC TRẢ VỀ TEXT THUẦN TÚY.
  2. TUYỆT ĐỐI KHÔNG LẶP LẠI CÂU TỪ. NẾU BẠN THẤY MÌNH ĐANG VIẾT LẶP LẠI MỘT CÂU (VÍ DỤ: "Lựa chọn của bạn là gì?"), HÃY DỪNG LẠI NGAY LẬP TỨC VÀ ĐÓNG KHỐI JSON.`;
          importedWorld.history[firstUserPromptIndex].parts[0].text = newPrompt;
        }
      }
      
      // 6. Run Migration Logic
      setMigrationProgress('Đang đắp thêm dữ liệu còn thiếu...');
      importedWorld.id = typeof crypto.randomUUID === 'function' 
        ? crypto.randomUUID() 
        : Date.now().toString(36) + Math.random().toString(36).substring(2);
      
      if (!importedWorld.timestamp) importedWorld.timestamp = Date.now();
      if (!importedWorld.currentResponse) throw new Error("Invalid save file: missing currentResponse");
      if (!importedWorld.invalidEntities) importedWorld.invalidEntities = [];
      if (!importedWorld.currentResponse.state) importedWorld.currentResponse.state = {} as any;

      const state = importedWorld.currentResponse.state;
      if (!state.Game_Status) state.Game_Status = "Đang diễn ra";
      if (!state.Pacing_State) state.Pacing_State = "DOWNTIME";
      if (!state.Dice_Roll_Log) {
        state.Dice_Roll_Log = { Action_Attempted: "N/A", Base_Roll: "N/A", Modifiers: "N/A", Final_Score: "N/A", Result_Logic: "N/A" };
      }
      if (!state.MC_Status) {
        state.MC_Status = { 
          HP_Current: 100, 
          HP_Max: 100, 
          Resource_Label: "Năng lượng", 
          Resource_Current: 100, 
          Resource_Max: 100, 
          Level: "Phàm Nhân", 
          Skills: [], 
          Skill_Mastery: [],
          Inventory: "Trống",
          Wealth: {
            Spirit_Stones: 0,
            Merit_Points: 0,
            Salary_Info: "Chưa có"
          }
        };
      } else if (!state.MC_Status.Wealth) {
        state.MC_Status.Wealth = {
          Spirit_Stones: 0,
          Merit_Points: 0,
          Salary_Info: "Chưa có"
        };
      }
      if (!state.Long_Term_Goals) state.Long_Term_Goals = [];
      if (!state.Available_Missions) state.Available_Missions = [];
      if (!state.Available_Shop_Items) state.Available_Shop_Items = [];
      if (!state.World_Variables) {
        state.World_Variables = { 
          Time_Passed: "0 ngày", 
          Current_Location: "Không rõ", 
          Current_Weather: "Bình thường", 
          Random_Event_Active: "None",
          In_World_Time: {
            Current_Day: 1,
            Elapsed_Time: "0 ngày",
            Deadline_Status: "Chưa có",
            Preparation_Level: "Sơ cấp"
          }
        };
      }
      if (!state.Global_Context) {
        state.Global_Context = { Organization_Hierarchy: "Không rõ", Entities_Present: [], Local_Resources: [], Conceptual_Map: [] };
      } else if (typeof state.Global_Context.Conceptual_Map === 'string') {
        // Keep it as string, StatusBoard handles both, but new entries will be arrays
      }
      if (!state.NPC_Tracker) state.NPC_Tracker = [];
      if (!state.Faction_Tracker) state.Faction_Tracker = [];
      if (!state.Unresolved_Consequences) state.Unresolved_Consequences = [];
      if (!state.Logical_Corrections) state.Logical_Corrections = [];
      
      // 7. Save and Load
      await saveChunksToDB(importedWorld.id);
      
      const worldToSave = { ...importedWorld };
      delete worldToSave.ragChunks;

      setWorlds(prev => [worldToSave, ...prev]);
      syncWorldToLocal(worldToSave);
      setNotification({ message: `Đã khôi phục và cập nhật thành công: ${worldToSave.name}`, type: 'success' });
      setShowMigrationModal(false);
      setMigrationJsonFile(null);
      setMigrationEpubFile(null);
      
      loadWorld(importedWorld);
      
    } catch (err: any) {
      console.error("Migration error:", err);
      setNotification({ message: 'Lỗi khi chuyển đổi: ' + (err.message || 'Không xác định'), type: 'error' });
    } finally {
      setIsMigrating(false);
    }
  };

  const handleStartGame = async (content: string) => {
    console.log("handleStartGame called with content length:", content.length);
    setPendingContent(content);
    setNewWorldName(`Thế giới ${worlds.length + 1}`);
    setShowNameModal(true);
  };

  const confirmCreateWorld = async () => {
    if (!pendingContent) return;
    const worldName = newWorldName.trim() || `Thế giới ${worlds.length + 1}`;
    
    setShowNameModal(false);
    setLoading(true);
    try {
      setLoadingMessage('ĐANG PHÂN MẢNH DỮ LIỆU (CHUNKING)...');
      // Process and index the text for RAG
      processAndIndexText(pendingContent);

      setLoadingMessage('ĐANG TRÍCH XUẤT LOREBOOK & ARC SUMMARY...');
      // Generate initial world context from the first 40k chars
      const initialText = pendingContent.substring(0, 40000);
      const worldContext = await generateWorldContext(initialText);

      setLoadingMessage('GM ĐANG KHỞI TẠO THẾ GIỚI...');
      console.log("Calling startGame service...");
      const { response, initialPrompt } = await startGame(pendingContent, worldContext);
      console.log("startGame response received:", response);
      const newHistory = [
        { role: 'user', parts: [{ text: initialPrompt }] },
        { role: 'model', parts: [{ text: JSON.stringify(response) }] }
      ];
      await createNewWorld(worldName, response, newHistory);
    } catch (error: any) {
      console.error("Error in handleStartGame:", error);
      setNotification({ message: error.message || 'Lỗi khi khởi tạo GM. Vui lòng thử lại.', type: 'error' });
    } finally {
      setLoading(false);
      setPendingContent(null);
    }
  };

  const handleAction = async (action: string, forceNormalMode: boolean = false) => {
    if (!action.trim() || loading) return;

    if (action.startsWith('/quarantine ') || action.startsWith('/spoil ')) {
      const entity = action.replace(/^\/(quarantine|spoil)\s+/, '').trim();
      if (entity) {
        if (!activeWorldId) {
          setNotification({ message: 'Vui lòng bắt đầu trò chơi trước khi dùng lệnh này.', type: 'error' });
          setUserInput('');
          return;
        }
        
        const currentWorld = worlds.find(w => w.id === activeWorldId);
        if (currentWorld) {
          const newInvalidEntities = [...(currentWorld.invalidEntities || []), entity];
          
          // Scrub history and current response
          const { scrubbedHistory, scrubbedResponse } = scrubCanonState(history, currentResponse, newInvalidEntities);
          
          const updatedWorld = {
            ...currentWorld,
            invalidEntities: newInvalidEntities,
            history: scrubbedHistory,
            currentResponse: scrubbedResponse || currentWorld.currentResponse,
            timestamp: Date.now()
          };
          
          setWorlds(prev => prev.map(w => w.id === activeWorldId ? updatedWorld : w));
          setHistory(scrubbedHistory);
          if (scrubbedResponse) setCurrentResponse(scrubbedResponse);
          syncWorldToLocal(updatedWorld);
          
          setNotification({ message: `Đã đưa "${entity}" vào danh sách cấm và làm sạch cốt truyện.`, type: 'success' });
          setUserInput('');
          return;
        }
      }
    }

    setLoading(true);
    setUserInput('');
    
    const isMemoryQuery = isMemoryMode && !forceNormalMode;
    let finalAction = isMemoryQuery ? `[MEMORY_QUERY] ${action}` : action;
    
    const currentWorld = worlds.find(w => w.id === activeWorldId);
    let usedCorrectionNotes = false;
    if (!isMemoryQuery && currentWorld && currentWorld.correctionNotes && currentWorld.correctionNotes.length > 0) {
      finalAction = `[GHI CHÚ SỬA LỖI LOGIC TỪ NGƯỜI CHƠI (Bắt buộc phải áp dụng vào cốt truyện từ bây giờ)]:\n${currentWorld.correctionNotes.join('\n\n')}\n\n[HÀNH ĐỘNG TIẾP THEO CỦA NGƯỜI CHƠI]:\n${finalAction}`;
      usedCorrectionNotes = true;
    }
    
    if (isMemoryQuery) {
      setLastMemoryQuery(action);
    }
    
    const newHistory = [...history, { role: 'user', parts: [{ text: finalAction }] }];
    
    try {
      // Retrieve context from RAG using both user action and current game state for better relevance
      const contextQuery = currentResponse 
        ? `${action} ${currentResponse.state.Current_Arc_Summary || ''} ${currentResponse.state.World_Variables.Current_Location || ''}`
        : action;
      
      const currentTurn = history.length;
      let historyContext: string[] = [];
      
      if (isMemoryQuery) {
        historyContext = history.map(h => {
          if (h.role === 'model') {
            try {
              const parsed = JSON.parse(h.parts[0].text);
              return parsed.story || '';
            } catch (e) {
              return h.parts[0].text;
            }
          }
          return h.parts[0].text;
        }).filter(text => text.length > 0);
      }

      // Only retrieve context if the action is meaningful or we have good context
      const retrievedContext = retrieveContext({
        text: contextQuery,
        mode: isMemoryQuery ? 'memory' : 'action',
        currentTurn,
        historyContext
      }, 2);
      
      let response;
      if (isMemoryQuery) {
        response = await askMemoryQuery(action, history, retrievedContext, currentWorld?.invalidEntities);
      } else {
        response = await sendAction(finalAction, history, retrievedContext, currentWorld?.invalidEntities);
      }
      
      if (isMemoryQuery) {
        setMemoryQueryResponse(response);
      } else {
        setCurrentResponse(response);
        const updatedHistory = [...newHistory, { role: 'model', parts: [{ text: JSON.stringify(response) }] }];
        setHistory(updatedHistory);
        
        // Clear correction notes after they are used
        if (usedCorrectionNotes && currentWorld) {
          const updatedWorld = { ...currentWorld, correctionNotes: [] };
          setWorlds(worlds.map(w => w.id === activeWorldId ? updatedWorld : w));
          syncWorldToLocal(updatedWorld);
        }
        
        saveCurrentWorld(response, updatedHistory);
        setMemoryQueryResponse(null);
      }
    } catch (error: any) {
      console.error(error);
      setNotification({ message: `Lỗi: ${error.message || 'GM đang bận suy tính... Thử lại sau giây lát.'}`, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateLibraryIndex = async () => {
    if (isGeneratingIndex) return;
    setIsGeneratingIndex(true);
    try {
      const currentWorld = worlds.find(w => w.id === activeWorldId);
      const index = await generateLibraryIndex(history, currentWorld?.invalidEntities);
      setLibraryIndex(index);
    } catch (error: any) {
      console.error("Generate library index error:", error);
      setNotification({ message: `Lỗi khi tạo danh mục: ${error.message}`, type: 'error' });
    } finally {
      setIsGeneratingIndex(false);
    }
  };

  const handleLibrarySearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!libraryQuery.trim() || isLibraryLoading) return;

    setIsLibraryLoading(true);
    setLibraryResponse(null);

    try {
      const currentWorld = worlds.find(w => w.id === activeWorldId);
      const retrievedContext = retrieveContext({
        text: libraryQuery,
        mode: 'memory',
        currentTurn: history.length,
        historyContext: []
      }, 3);

      const response = await askLibraryQuery(libraryQuery, history, retrievedContext, currentWorld?.invalidEntities);
      setLibraryResponse(response.explanation);
    } catch (error: any) {
      console.error("Library search error:", error);
      setLibraryResponse(`Lỗi khi tra cứu: ${error.message || 'Không thể kết nối với Tàng Kinh Các.'}`);
    } finally {
      setIsLibraryLoading(false);
    }
  };

  const handleRewind = (turns: number) => {
    if (loading || history.length <= 1) return;
    
    const stepsToRemove = turns * 2;
    const newHistory = history.slice(0, Math.max(1, history.length - stepsToRemove));
    
    const lastModelResponse = newHistory[newHistory.length - 1];
    if (lastModelResponse && lastModelResponse.role === 'model') {
      try {
        const parsedResponse = JSON.parse(lastModelResponse.parts[0].text);
        setHistory(newHistory);
        setCurrentResponse(parsedResponse);
        saveCurrentWorld(parsedResponse, newHistory);
      } catch (e) {
        console.error("Failed to parse history response during rewind:", e);
      }
    }
  };

  const handleBranchFromChapter = async (chapterId: number) => {
    if (loading) return;
    
    const totalChapters = history.filter(h => h.role === 'model').length;
    if (chapterId >= totalChapters - 1) {
      setViewingChapter(null);
      return;
    }
    
    const stepsToRemove = (totalChapters - 1 - chapterId) * 2;
    const newHistory = history.slice(0, Math.max(1, history.length - stepsToRemove));
    
    const lastModelResponse = newHistory[newHistory.length - 1];
    if (lastModelResponse && lastModelResponse.role === 'model') {
      try {
        const parsedResponse = JSON.parse(lastModelResponse.parts[0].text);
        
        const currentWorld = worlds.find(w => w.id === activeWorldId);
        const baseName = currentWorld ? currentWorld.name.split(' - Branch')[0] : 'Thế giới';
        const newName = `${baseName} - Branch từ Hồi ${chapterId + 1}`;
        
        const correctionNotes = memoryQueryResponse 
          ? [`Phát hiện lỗi từ truy vấn: "${lastMemoryQuery}"\nGM phản hồi: "${memoryQueryResponse.story}"`] 
          : [];
          
        await createNewWorld(newName, parsedResponse, newHistory, correctionNotes, currentWorld?.invalidEntities);
        setNotification({ message: `Đã tạo nhánh mới từ Hồi ${chapterId + 1}.`, type: 'success' });
        setMemoryQueryResponse(null);
        setIsMemoryMode(false);
      } catch (e) {
        console.error("Failed to parse history response during branch:", e);
        setNotification({ message: 'Lỗi khi tạo nhánh mới.', type: 'error' });
      }
    }
    setViewingChapter(null);
  };

  const loadWorld = async (world: WorldSave) => {
    setLoading(true);
    const hasChunks = await loadChunksFromDB(world.id);
    setLoading(false);
    
    if (!hasChunks) {
      setNotification({ message: 'Không tìm thấy dữ liệu truyện gốc. Vui lòng sử dụng tính năng "Khôi phục & Cập nhật Save" để tải lại file EPUB.', type: 'error' });
      return;
    }
    
    setActiveWorldId(world.id);
    setCurrentResponse(world.currentResponse);
    setHistory(world.history);
    setGameStarted(true);
  };

  const handleGenerateMap = async () => {
    if (!currentResponse || isGeneratingMap) return;
    setIsGeneratingMap(true);
    try {
      const image = await generateMapImage(
        currentResponse.state.World_Variables.Current_Location,
        currentResponse.story
      );
      if (image) {
        setMapImage(image);
        setShowMapModal(true);
      } else {
        setNotification({ message: 'Không thể vẽ bản đồ lúc này. Vui lòng thử lại sau.', type: 'error' });
      }
    } catch (error) {
      console.error("Failed to generate map", error);
      setNotification({ message: 'Lỗi khi vẽ bản đồ.', type: 'error' });
    } finally {
      setIsGeneratingMap(false);
    }
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentResponse]);

  const chapters = history
    .filter(h => h.role === 'model')
    .map((h, i) => {
      try {
        const parsed = JSON.parse(h.parts[0].text);
        // Extract a title or first few words from story
        const titleMatch = parsed.story.match(/#+\s*(.*)/) || parsed.story.match(/\*\*(.*)\*\*/);
        const title = titleMatch ? titleMatch[1] : parsed.story.substring(0, 30) + '...';
        return { id: i, title, story: parsed.story, state: parsed.state };
      } catch (e) {
        return { id: i, title: `Chương ${i + 1}`, story: '', state: null };
      }
    });

  const [viewingChapter, setViewingChapter] = useState<any | null>(null);

  if (!gameStarted) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#0c0c0c]">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl w-full space-y-12"
        >
          <div className="text-center space-y-4 relative">
            <button
              onClick={async () => {
                if ((window as any).aistudio?.openSelectKey) {
                  await (window as any).aistudio.openSelectKey();
                } else {
                  setNotification({ message: 'Tính năng chọn API Key không khả dụng trong môi trường này.', type: 'error' });
                }
              }}
              className="absolute top-0 right-0 p-2 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-400 hover:text-orange-500 transition-colors flex items-center gap-2 text-[10px] font-mono uppercase"
              title="Cài đặt API Key cá nhân"
            >
              <Key className="w-4 h-4" />
              API Key
            </button>
            <h1 className="text-6xl font-black tracking-tighter text-white uppercase italic">
              Ruthless <span className="text-orange-600">GM</span>
            </h1>
            <p className="text-zinc-500 font-mono text-sm uppercase tracking-[0.2em]">
              Thế giới khắc nghiệt. Nhân quả vẹn toàn.
            </p>
          </div>

          <EpubUploader onContentExtracted={handleStartGame} />

          <div className="space-y-6">
            <div className="flex items-center justify-between px-2">
              <h2 className="text-[10px] font-mono text-zinc-500 uppercase tracking-[0.3em]">Các thế giới hiện có</h2>
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setShowMigrationModal(true)}
                  className="flex items-center gap-2 text-[10px] font-mono text-orange-500 hover:text-orange-400 transition-colors uppercase tracking-widest"
                >
                  <RefreshCcw className="w-3 h-3" />
                  Khôi phục & Cập nhật
                </button>
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 text-[10px] font-mono text-orange-500 hover:text-orange-400 transition-colors uppercase tracking-widest"
                >
                  <Upload className="w-3 h-3" />
                  Nhập từ máy
                </button>
              </div>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImportFile} 
                accept=".json" 
                className="hidden" 
              />
            </div>

            <div className="grid grid-cols-1 gap-3">
              {worlds.map(world => (
                <motion.div
                  key={world.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  onClick={() => loadWorld(world)}
                  className="group flex items-center gap-4 p-4 bg-zinc-900/50 border border-zinc-800 rounded-2xl hover:border-orange-500/50 transition-all cursor-pointer"
                >
                  <div className="p-2 bg-zinc-800 rounded-lg group-hover:bg-orange-500/10 transition-colors">
                    <BookOpen className="w-5 h-5 text-zinc-500 group-hover:text-orange-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-white truncate">{world.name}</p>
                    <p className="text-[10px] font-mono text-zinc-600 uppercase">
                      {new Date(world.timestamp).toLocaleString('vi-VN')}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={(e) => exportWorld(world, e)}
                      className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-emerald-500 transition-colors"
                      title="Tải về máy"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={(e) => deleteWorld(world.id, e)}
                      className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-red-500 transition-colors"
                      title="Xóa thế giới"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              ))}

              {worlds.length === 0 && (
                <div className="p-8 border border-dashed border-zinc-800 rounded-2xl text-center">
                  <p className="text-xs font-mono text-zinc-600 uppercase">Chưa có thế giới nào được tạo</p>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[10px] font-mono text-zinc-600 uppercase tracking-widest">
            <div className="p-4 border border-zinc-900 rounded-xl text-center">NPC Tư Lợi</div>
            <div className="p-4 border border-zinc-900 rounded-xl text-center">Logic Truyện Gốc</div>
            <div className="p-4 border border-zinc-900 rounded-xl text-center">Hệ Quả Tàn Khốc</div>
          </div>
        </motion.div>

        {loading && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center z-50">
            <RefreshCcw className="w-12 h-12 text-orange-500 animate-spin mb-4" />
            <p className="text-orange-500 font-mono text-sm animate-pulse text-center px-4">{loadingMessage}</p>
            {loadingTime > 0 && (
              <p className="text-zinc-500 font-mono text-xs mt-2">
                Thời gian: {Math.floor(loadingTime / 60)}:{(loadingTime % 60).toString().padStart(2, '0')}
              </p>
            )}
            {loadingTime > 15 && (
              <button 
                onClick={() => {
                  setLoading(false);
                  setNotification({ message: 'Đã hủy thao tác.', type: 'error' });
                }}
                className="mt-8 px-6 py-2 border border-red-500/50 text-red-500 rounded-full font-mono text-xs uppercase tracking-widest hover:bg-red-500/10 transition-colors"
              >
                Hủy bỏ
              </button>
            )}
          </div>
        )}

        {/* Notification Toast */}
        <AnimatePresence>
          {notification && (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] px-6 py-3 rounded-xl border shadow-2xl flex items-center gap-3 font-mono text-xs uppercase tracking-widest ${
                notification.type === 'success' 
                  ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-400' 
                  : 'bg-red-950/90 border-red-500/50 text-red-400'
              }`}
            >
              <div className={`w-2 h-2 rounded-full animate-pulse ${notification.type === 'success' ? 'bg-emerald-500' : 'bg-red-500'}`} />
              {notification.message}
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {worldToDelete && (
            <div className="fixed inset-0 bg-black/90 backdrop-blur-xl flex items-center justify-center z-[70] p-6">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="max-w-md w-full bg-zinc-900 border border-zinc-800 p-8 rounded-3xl shadow-2xl space-y-6"
              >
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-white uppercase tracking-tight">Xóa thế giới?</h3>
                  <p className="text-zinc-500 text-xs font-mono uppercase">Hành động này không thể hoàn tác. Mọi nhân quả sẽ tan biến.</p>
                </div>
                
                <div className="flex gap-3">
                  <button 
                    onClick={() => setWorldToDelete(null)}
                    className="flex-1 py-3 bg-zinc-800 text-zinc-400 font-bold rounded-xl hover:bg-zinc-700 transition-all uppercase text-xs tracking-widest"
                  >
                    Hủy
                  </button>
                  <button 
                    onClick={confirmDeleteWorld}
                    className="flex-1 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-500 transition-all uppercase text-xs tracking-widest"
                  >
                    Xác nhận xóa
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showRestartModal && (
            <div className="fixed inset-0 bg-black/90 backdrop-blur-xl flex items-center justify-center z-[70] p-6">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="max-w-md w-full bg-zinc-900 border border-zinc-800 p-8 rounded-3xl shadow-2xl space-y-6"
              >
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-white uppercase tracking-tight">Khởi động lại thế giới?</h3>
                  <p className="text-zinc-500 text-xs font-mono uppercase">Mọi tiến trình hiện tại sẽ bị xóa bỏ. Bạn sẽ quay về khoảnh khắc bắt đầu hành trình.</p>
                </div>
                
                <div className="flex gap-3">
                  <button 
                    onClick={() => setShowRestartModal(false)}
                    className="flex-1 py-3 bg-zinc-800 text-zinc-400 font-bold rounded-xl hover:bg-zinc-700 transition-all uppercase text-xs tracking-widest"
                  >
                    Hủy
                  </button>
                  <button 
                    onClick={confirmRestartWorld}
                    className="flex-1 py-3 bg-orange-600 text-white font-bold rounded-xl hover:bg-orange-500 transition-all uppercase text-xs tracking-widest"
                  >
                    Xác nhận khởi động lại
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showBackupReminder && (
            <div className="fixed inset-0 bg-black/90 backdrop-blur-xl flex items-center justify-center z-[70] p-6">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="max-w-md w-full bg-zinc-900 border border-zinc-800 p-8 rounded-3xl shadow-2xl space-y-6"
              >
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-orange-500 uppercase tracking-tight">Nhắc nhở sao lưu</h3>
                  <p className="text-zinc-400 text-sm">Bạn đã trải qua một chặng đường dài (15 hồi). Hãy tải file save về máy để đảm bảo không mất dữ liệu nhé!</p>
                </div>
                
                <div className="flex flex-col gap-3">
                  <button 
                    onClick={(e) => {
                      const currentWorld = worlds.find(w => w.id === activeWorldId);
                      if (currentWorld) exportWorld(currentWorld, e as any);
                      setShowBackupReminder(false);
                    }}
                    className="w-full py-3 bg-orange-600 text-white font-bold rounded-xl hover:bg-orange-500 transition-all uppercase text-xs tracking-widest flex items-center justify-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Tải Save Ngay
                  </button>
                  <button 
                    onClick={() => setShowBackupReminder(false)}
                    className="w-full py-3 bg-zinc-800 text-zinc-400 font-bold rounded-xl hover:bg-zinc-700 transition-all uppercase text-xs tracking-widest"
                  >
                    Để sau
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showMigrationModal && (
            <div className="fixed inset-0 bg-black/90 backdrop-blur-xl flex items-center justify-center z-[60] p-6">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="max-w-md w-full bg-zinc-900 border border-zinc-800 p-8 rounded-3xl shadow-2xl space-y-6"
              >
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-white uppercase tracking-tight">Khôi phục & Cập nhật Save</h3>
                  <p className="text-zinc-500 text-xs font-mono uppercase">Tải lên file save cũ (.json) và file truyện (.epub) để hệ thống tự động đắp thêm dữ liệu còn thiếu và cập nhật bối cảnh mới nhất.</p>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-mono text-zinc-500 uppercase tracking-widest mb-2">1. File Save Cũ (.json)</label>
                    <input 
                      type="file" 
                      accept=".json"
                      onChange={(e) => setMigrationJsonFile(e.target.files?.[0] || null)}
                      className="w-full text-xs text-zinc-300 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-orange-500/10 file:text-orange-500 hover:file:bg-orange-500/20"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-zinc-500 uppercase tracking-widest mb-2">2. File Truyện Gốc (.epub)</label>
                    <input 
                      type="file" 
                      accept=".epub"
                      onChange={(e) => setMigrationEpubFile(e.target.files?.[0] || null)}
                      className="w-full text-xs text-zinc-300 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-orange-500/10 file:text-orange-500 hover:file:bg-orange-500/20"
                    />
                  </div>
                </div>

                {isMigrating ? (
                  <div className="flex flex-col items-center gap-3 py-4">
                    <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
                    <p className="text-[10px] font-mono text-orange-500 animate-pulse uppercase tracking-widest">{migrationProgress}</p>
                  </div>
                ) : (
                  <div className="flex gap-3">
                    <button 
                      onClick={() => {
                        setShowMigrationModal(false);
                        setMigrationJsonFile(null);
                        setMigrationEpubFile(null);
                      }}
                      className="flex-1 py-3 bg-zinc-800 text-zinc-400 font-bold rounded-xl hover:bg-zinc-700 transition-all uppercase text-xs tracking-widest"
                    >
                      Hủy
                    </button>
                    <button 
                      onClick={handleMigration}
                      disabled={!migrationJsonFile || !migrationEpubFile}
                      className="flex-1 py-3 bg-orange-600 text-white font-bold rounded-xl hover:bg-orange-500 transition-all uppercase text-xs tracking-widest disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Bắt đầu
                    </button>
                  </div>
                )}
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showNameModal && (
            <div className="fixed inset-0 bg-black/90 backdrop-blur-xl flex items-center justify-center z-[60] p-6">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="max-w-md w-full bg-zinc-900 border border-zinc-800 p-8 rounded-3xl shadow-2xl space-y-6"
              >
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-white uppercase tracking-tight">Đặt tên thế giới</h3>
                  <p className="text-zinc-500 text-xs font-mono uppercase">GM cần một danh xưng cho thực tại này</p>
                </div>
                
                <input 
                  autoFocus
                  type="text"
                  value={newWorldName}
                  onChange={(e) => setNewWorldName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && confirmCreateWorld()}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-4 px-6 text-white focus:outline-none focus:border-orange-500 transition-all font-serif"
                  placeholder="Tên thế giới..."
                />

                <div className="flex gap-3">
                  <button 
                    onClick={() => setShowNameModal(false)}
                    className="flex-1 py-3 bg-zinc-800 text-zinc-400 font-bold rounded-xl hover:bg-zinc-700 transition-all uppercase text-xs tracking-widest"
                  >
                    Hủy
                  </button>
                  <button 
                    onClick={confirmCreateWorld}
                    className="flex-2 py-3 bg-orange-600 text-white font-bold rounded-xl hover:bg-orange-500 transition-all uppercase text-xs tracking-widest"
                  >
                    Bắt đầu hành trình
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-[#0c0c0c] text-zinc-200 overflow-hidden">
      {/* Left Sidebar */}
      <aside className="border-r border-zinc-900 flex flex-col w-80 hidden lg:flex">
        {/* Sidebar Tabs */}
        <div className="flex border-b border-zinc-900">
          <button 
            onClick={() => setLeftSidebarTab('status')}
            className={`flex-1 py-4 text-[10px] font-mono uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${leftSidebarTab === 'status' ? 'text-orange-500 bg-zinc-900/50' : 'text-zinc-600 hover:text-zinc-400'}`}
          >
            <Activity className="w-3 h-3" />
            Trạng thái
          </button>
          <button 
            onClick={() => setLeftSidebarTab('history')}
            className={`flex-1 py-4 text-[10px] font-mono uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${leftSidebarTab === 'history' ? 'text-orange-500 bg-zinc-900/50' : 'text-zinc-600 hover:text-zinc-400'}`}
          >
            <List className="w-3 h-3" />
            Mục lục
          </button>
          <button 
            onClick={() => setLeftSidebarTab('library')}
            className={`flex-1 py-4 text-[10px] font-mono uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${leftSidebarTab === 'library' ? 'text-orange-500 bg-zinc-900/50' : 'text-zinc-600 hover:text-zinc-400'}`}
          >
            <BookOpen className="w-3 h-3" />
            Thư viện
          </button>
        </div>

        <div className="flex-1 overflow-hidden">
          {leftSidebarTab === 'status' ? (
            <div className="p-6 h-full">
              {currentResponse && (
                <StatusBoard 
                  state={currentResponse.state} 
                  onGenerateMap={handleGenerateMap}
                  isGeneratingMap={isGeneratingMap}
                />
              )}
            </div>
          ) : leftSidebarTab === 'history' ? (
            <div className="p-6 h-full flex flex-col gap-4 overflow-y-auto custom-scrollbar">
              <div className="flex items-center gap-2 mb-2 text-orange-500">
                <History className="w-5 h-5" />
                <h3 className="font-bold uppercase tracking-wider text-xs">Hồi ức hành trình</h3>
              </div>
              <div className="space-y-2">
                {chapters.map((chapter, idx) => (
                  <button
                    key={idx}
                    onClick={() => setViewingChapter(chapter)}
                    className="w-full text-left p-3 rounded-xl border border-zinc-800 bg-zinc-900/30 hover:bg-orange-500/10 hover:border-orange-500/50 transition-all group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono text-zinc-600 uppercase">Hồi {idx + 1}</span>
                      <ChevronRight className="w-3 h-3 text-zinc-700 group-hover:text-orange-500" />
                    </div>
                    <p className="text-xs text-zinc-300 line-clamp-2 group-hover:text-white transition-colors">
                      {chapter.title}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-6 h-full flex flex-col gap-4 overflow-y-auto custom-scrollbar">
              <div className="flex items-center gap-2 mb-2 text-orange-500">
                <BookOpen className="w-5 h-5" />
                <h3 className="font-bold uppercase tracking-wider text-xs">Tàng Kinh Các</h3>
              </div>
              <p className="text-xs text-zinc-400 mb-2">Tra cứu thông tin về linh dược, thảo mộc, công pháp, hoặc các khái niệm trong thế giới tu tiên.</p>
              
              <form onSubmit={handleLibrarySearch} className="flex gap-2">
                <input
                  type="text"
                  value={libraryQuery}
                  onChange={(e) => setLibraryQuery(e.target.value)}
                  placeholder="Ví dụ: Linh khí đan..."
                  className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-orange-500/50"
                  disabled={isLibraryLoading}
                />
                <button
                  type="submit"
                  disabled={isLibraryLoading || !libraryQuery.trim()}
                  className="bg-orange-600 hover:bg-orange-500 text-white p-2 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  {isLibraryLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </button>
              </form>

              {libraryResponse && (
                <div className="mt-4 bg-zinc-900/50 border border-zinc-800 rounded-xl p-4 relative">
                  <button 
                    onClick={() => setLibraryResponse(null)}
                    className="absolute top-2 right-2 p-1 text-zinc-500 hover:text-white bg-zinc-800 rounded-md"
                  >
                    <X className="w-3 h-3" />
                  </button>
                  <div className="prose prose-invert prose-sm max-w-none markdown-body mt-2">
                    <Markdown>{libraryResponse}</Markdown>
                  </div>
                </div>
              )}

              {!libraryResponse && (
                <div className="mt-4">
                  {!libraryIndex ? (
                    <button
                      onClick={handleGenerateLibraryIndex}
                      disabled={isGeneratingIndex}
                      className="w-full py-3 bg-zinc-900 border border-zinc-800 hover:border-orange-500/50 rounded-xl text-sm text-zinc-300 hover:text-orange-500 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {isGeneratingIndex ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Đang sắp xếp Tàng Kinh Các...
                        </>
                      ) : (
                        <>
                          <BookOpen className="w-4 h-4" />
                          Khám phá Tàng Kinh Các
                        </>
                      )}
                    </button>
                  ) : (
                    <div className="space-y-6">
                      {libraryIndex.map((category, idx) => (
                        <div key={idx} className="space-y-3">
                          <h4 className="text-sm font-bold text-orange-500 border-b border-zinc-800 pb-1">{category.category}</h4>
                          <div className="space-y-4 pl-2">
                            {category.subcategories.map((sub, subIdx) => (
                              <div key={subIdx} className="space-y-2">
                                <h5 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">{sub.name}</h5>
                                <div className="grid grid-cols-1 gap-2">
                                  {sub.items.map((item, itemIdx) => (
                                    <button
                                      key={itemIdx}
                                      onClick={() => {
                                        setLibraryQuery(item.name);
                                        handleLibrarySearch({ preventDefault: () => {} } as React.FormEvent);
                                      }}
                                      className="text-left p-2 rounded-lg bg-zinc-900/50 border border-zinc-800 hover:border-orange-500/50 hover:bg-orange-500/10 transition-all group"
                                    >
                                      <div className="text-sm font-medium text-zinc-200 group-hover:text-orange-400">{item.name}</div>
                                      <div className="text-xs text-zinc-500 line-clamp-1">{item.shortDescription}</div>
                                    </button>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </aside>

      {/* Main Game Area */}
      <main className="flex-1 flex flex-col relative">
        {/* Header */}
        <header className="h-16 border-b border-zinc-900 flex items-center justify-between px-8 bg-zinc-950/50 backdrop-blur-md z-10">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <Terminal className="w-5 h-5 text-orange-500" />
              <div className="flex flex-col">
                <span className="font-mono text-[10px] uppercase tracking-widest text-zinc-400">Session Active</span>
                {isSyncing && (
                  <span className="text-[8px] font-mono text-orange-500 uppercase animate-pulse">Syncing to backend...</span>
                )}
              </div>
            </div>
            <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
              <span className="text-[10px] font-mono text-emerald-500 uppercase tracking-tighter">
                {worlds.find(w => w.id === activeWorldId)?.name || 'World Active'}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowMobileStats(true)}
              className="lg:hidden p-2 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-400 hover:text-orange-500 transition-colors"
              title="Xem trạng thái"
            >
              <Activity className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setShowMobileLibrary(true)}
              className="lg:hidden p-2 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-400 hover:text-orange-500 transition-colors"
              title="Tàng Kinh Các"
            >
              <BookOpen className="w-5 h-5" />
            </button>
            <button 
              onClick={() => handleRewind(1)}
              disabled={loading || history.length <= 1}
              className="text-[10px] font-mono uppercase text-zinc-600 hover:text-orange-500 transition-colors flex items-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed"
              title="Quay lại 1 lượt"
            >
              <RotateCcw className="w-3 h-3" />
              Hoàn tác
            </button>
            <button 
              onClick={() => handleRewind(10)}
              disabled={loading || history.length <= 1}
              className="text-[10px] font-mono uppercase text-zinc-600 hover:text-orange-500 transition-colors flex items-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed"
              title="Quay lại 10 lượt"
            >
              <History className="w-3 h-3" />
              -10 Lượt
            </button>
            <button 
              onClick={() => setShowRestartModal(true)}
              disabled={loading || history.length <= 1}
              className="text-[10px] font-mono uppercase text-zinc-600 hover:text-red-500 transition-colors flex items-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed"
              title="Khởi động lại từ đầu"
            >
              <RotateCcw className="w-3 h-3" />
              Khởi động lại
            </button>
            <button 
              onClick={(e) => {
                const world = worlds.find(w => w.id === activeWorldId);
                if (world) exportWorld(world, e as any);
              }}
              className="text-[10px] font-mono uppercase text-zinc-600 hover:text-emerald-500 transition-colors flex items-center gap-2"
            >
              <Download className="w-3 h-3" />
              Tải về máy
            </button>
            <button 
              onClick={async () => {
                if ((window as any).aistudio?.openSelectKey) {
                  await (window as any).aistudio.openSelectKey();
                } else {
                  setNotification({ message: 'Tính năng chọn API Key không khả dụng trong môi trường này.', type: 'error' });
                }
              }}
              className="text-[10px] font-mono uppercase text-zinc-600 hover:text-orange-500 transition-colors flex items-center gap-2"
              title="Cài đặt API Key cá nhân"
            >
              <Key className="w-3 h-3" />
              API Key
            </button>
            <button 
              onClick={() => window.location.reload()}
              className="text-[10px] font-mono uppercase text-zinc-600 hover:text-orange-500 transition-colors flex items-center gap-2"
            >
              <RefreshCcw className="w-3 h-3" />
              Thoát thế giới
            </button>
          </div>
        </header>

        {/* Story Content */}
        <div className="flex-1 overflow-y-auto p-8 lg:p-12 custom-scrollbar">
          <div className="max-w-3xl mx-auto space-y-12 pb-32">
            <AnimatePresence mode="wait">
              {(memoryQueryResponse || currentResponse) && (() => {
                const displayResponse = memoryQueryResponse || currentResponse!;
                return (
                  <motion.div
                    key={displayResponse.story}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    className="markdown-body"
                  >
                    {memoryQueryResponse && (
                      <div className="mb-6 p-4 bg-orange-500/10 border border-orange-500/30 rounded-xl">
                        <span className="text-xs font-mono text-orange-500 uppercase tracking-widest flex items-center gap-2 mb-2">
                          <Brain className="w-4 h-4" />
                          Kết quả Truy vấn Ký ức
                        </span>
                        <p className="text-sm text-orange-400/80 italic">Đây là thông tin tra cứu, không ảnh hưởng đến cốt truyện chính. Bạn có thể tạo nhánh mới từ Hồi trước nếu phát hiện lỗi logic.</p>
                      </div>
                    )}
                    <Markdown>{displayResponse.story}</Markdown>
                    
                    {/* Choices */}
                    {displayResponse.state?.Game_Status === 'Game_Over' ? (
                      <div className="mt-12 p-6 border border-red-900/50 bg-red-950/20 rounded-2xl text-center space-y-4">
                        <h3 className="text-2xl font-black text-red-500 uppercase tracking-widest">Tử Vong</h3>
                        <p className="text-red-400/80 text-sm">Hành trình của bạn đã kết thúc tại đây. Bạn có thể dùng tính năng Hoàn tác để thay đổi số phận.</p>
                      </div>
                    ) : (
                      <div className="mt-12 space-y-3">
                        {!memoryQueryResponse && <p className="text-[10px] font-mono uppercase text-zinc-600 tracking-[0.3em] mb-4">Lựa chọn hành động</p>}
                        {!memoryQueryResponse && displayResponse.choices?.map((choice, i) => (
                          <button
                            key={i}
                            onClick={() => handleAction(choice)}
                            disabled={loading}
                            className="w-full text-left p-4 rounded-xl border border-zinc-800 bg-zinc-900/30 hover:bg-orange-500/10 hover:border-orange-500/50 transition-all group flex items-center justify-between"
                          >
                            <span className="text-lg text-zinc-300 group-hover:text-white transition-colors">{choice}</span>
                            <ChevronRight className="w-5 h-5 text-zinc-700 group-hover:text-orange-500 transition-colors" />
                          </button>
                        ))}
                        {(!displayResponse.choices || displayResponse.choices.length === 0 || memoryQueryResponse) && (
                          <div className="space-y-6">
                            {!memoryQueryResponse && <p className="text-sm text-zinc-500 italic">Không có lựa chọn nào khả dụng. Hãy tự nhập hành động của bạn.</p>}
                            
                            {memoryQueryResponse && (
                              <motion.button
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                onClick={() => {
                                  setMemoryQueryResponse(null);
                                  setIsMemoryMode(false);
                                }}
                                className="flex items-center gap-3 px-8 py-4 bg-zinc-800 hover:bg-zinc-700 text-orange-500 border border-zinc-700 rounded-2xl transition-all uppercase text-xs font-bold tracking-[0.2em] shadow-xl"
                              >
                                <RotateCcw className="w-4 h-4" />
                                Đóng Truy vấn & Quay lại cốt truyện
                              </motion.button>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </motion.div>
                );
              })()}
            </AnimatePresence>
            <div ref={chatEndRef} />
          </div>
        </div>

        {/* Input Area */}
        {currentResponse?.state?.Game_Status !== 'Game_Over' && (
          <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-[#0c0c0c] via-[#0c0c0c] to-transparent">
            <div className="max-w-3xl mx-auto space-y-4">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => {
                    setIsMemoryMode(!isMemoryMode);
                    if (isMemoryMode) {
                      setMemoryQueryResponse(null);
                    }
                  }}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all text-[10px] font-mono uppercase tracking-widest ${isMemoryMode ? 'bg-orange-600 border-orange-500 text-white shadow-lg shadow-orange-500/20' : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-orange-500 hover:border-orange-500/50'}`}
                >
                  <Brain className="w-3 h-3" />
                  {isMemoryMode ? 'Đóng Truy vấn' : 'Hỏi GM về quá khứ'}
                </button>
                {isMemoryMode && (
                  <>
                    <button
                      onClick={() => {
                        setIsMemoryMode(false);
                        if (userInput.trim()) {
                          const actionWithContext = memoryQueryResponse 
                            ? `[GHI CHÚ TỪ TRUY VẤN KÝ ỨC TRƯỚC ĐÓ]:\nTruy vấn: ${lastMemoryQuery}\nPhản hồi: ${memoryQueryResponse.story}\n\n[HÀNH ĐỘNG CỦA NGƯỜI CHƠI]:\n${userInput}`
                            : userInput;
                          handleAction(actionWithContext, true);
                        }
                        setMemoryQueryResponse(null);
                      }}
                      className="flex items-center gap-2 px-4 py-2 rounded-full border border-emerald-500/50 bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600 hover:text-white transition-all text-[10px] font-mono uppercase tracking-widest"
                      title="Thoát chế độ truy vấn. Nếu có nhập nội dung, sẽ gửi như hành động bình thường để tiếp tục cốt truyện."
                    >
                      <ChevronRight className="w-3 h-3" />
                      Tiếp tục
                    </button>
                    <span className="text-[10px] font-mono text-orange-500/70 italic animate-pulse">
                      * GM sẽ chỉ tiết lộ thông tin thuần túy, không đẩy tình tiết.
                    </span>
                  </>
                )}
              </div>
              <div className="relative">
                {!isMemoryMode && currentResponse?.state?.MC_Status?.Skills && currentResponse.state.MC_Status.Skills.length > 0 && (
                  <div className="mb-3 relative">
                    <button
                      onClick={() => setShowSkillMenu(!showSkillMenu)}
                      className="flex items-center gap-2 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-cyan-400 border border-zinc-700 rounded-xl transition-all text-[10px] font-mono uppercase tracking-widest shadow-lg"
                    >
                      <Activity className="w-3 h-3" />
                      Thực hiện chiêu thức
                    </button>
                    
                    <AnimatePresence>
                      {showSkillMenu && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 10 }}
                          className="absolute bottom-full left-0 mb-2 w-80 max-h-64 overflow-y-auto custom-scrollbar bg-zinc-900 border border-zinc-700 rounded-xl p-2 shadow-2xl z-50 flex flex-col gap-1"
                        >
                          <div className="text-[10px] text-zinc-500 uppercase px-2 py-1 border-b border-zinc-800 mb-1">Chọn chiêu thức</div>
                          {currentResponse.state.MC_Status.Skills.map((skill: any, idx) => (
                            <button
                              key={idx}
                              onClick={() => {
                                const skillName = typeof skill === 'string' ? skill : skill.Name;
                                setUserInput(`Sử dụng chiêu thức: ${skillName}`);
                                setShowSkillMenu(false);
                              }}
                              className="text-left px-3 py-2 hover:bg-zinc-800 rounded-lg transition-colors group"
                            >
                              <div className="text-cyan-400 font-bold text-sm group-hover:text-cyan-300">{typeof skill === 'string' ? skill : skill.Name}</div>
                              {typeof skill !== 'string' && <div className="text-[10px] text-zinc-400 mt-1 line-clamp-2">{skill.Description}</div>}
                            </button>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}
                <input
                  type="text"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAction(userInput)}
                  placeholder={isMemoryMode ? "Hỏi bất cứ điều gì về quá khứ hoặc trạng thái hiện tại..." : "Tự nhập hành động của bạn (tối đa 200 ký tự)..."}
                  maxLength={200}
                  className={`w-full bg-zinc-900 border rounded-2xl py-5 pl-6 pr-16 text-lg focus:outline-none transition-all font-serif ${isMemoryMode ? 'border-orange-500/50 focus:border-orange-500 ring-1 ring-orange-500/20' : 'border-zinc-800 focus:border-orange-500/50'}`}
                />
                <button
                  onClick={() => handleAction(userInput)}
                  disabled={loading || !userInput.trim()}
                  className={`absolute right-3 top-1/2 -translate-y-1/2 p-3 rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${isMemoryMode ? 'bg-orange-600 hover:bg-orange-500 text-white' : 'bg-orange-600 text-white hover:bg-orange-500'}`}
                >
                  <Send className="w-6 h-6" />
                </button>
              </div>
            </div>
          </div>
        )}

        {loading && (
          <div className="absolute top-20 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-50">
            <div className="px-4 py-2 bg-orange-500 text-black text-[10px] font-mono uppercase tracking-widest rounded-full animate-pulse shadow-lg shadow-orange-500/20">
              {loadingMessage} ({Math.floor(loadingTime / 60)}:{(loadingTime % 60).toString().padStart(2, '0')})
            </div>
            {loadingTime > 15 && (
              <button 
                onClick={() => {
                  setLoading(false);
                  setNotification({ message: 'Đã hủy thao tác.', type: 'error' });
                }}
                className="px-3 py-1 bg-zinc-900 border border-red-500/50 text-red-500 rounded-full font-mono text-[10px] uppercase tracking-widest hover:bg-red-500/10 transition-colors shadow-lg"
              >
                Hủy bỏ
              </button>
            )}
          </div>
        )}
      </main>

      {/* Mobile Stats Toggle (Optional improvement) */}
      
      {/* Map Modal */}
      <AnimatePresence>
        {showMobileStats && currentResponse && (
          <div className="fixed inset-0 z-[60] lg:hidden flex justify-end">
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-full max-w-xs bg-zinc-950 border-l border-zinc-900 h-full flex flex-col shadow-2xl"
            >
              <div className="p-6 border-b border-zinc-900 flex items-center justify-between bg-zinc-950/50">
                <div className="flex items-center gap-2 text-orange-500">
                  <Activity className="w-5 h-5" />
                  <h3 className="font-bold uppercase tracking-wider text-xs">Trạng thái nhân vật</h3>
                </div>
                <button 
                  onClick={() => setShowMobileStats(false)}
                  className="p-2 hover:bg-zinc-900 rounded-lg text-zinc-500 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
                <StatusBoard 
                  state={currentResponse.state} 
                  onGenerateMap={handleGenerateMap}
                  isGeneratingMap={isGeneratingMap}
                />
              </div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMobileStats(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm -z-10"
            />
          </div>
        )}
      </AnimatePresence>

      {/* Mobile Library Modal */}
      <AnimatePresence>
        {showMobileLibrary && (
          <div className="fixed inset-0 z-[60] lg:hidden flex justify-end">
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-full max-w-xs bg-zinc-950 border-l border-zinc-900 h-full flex flex-col shadow-2xl"
            >
              <div className="p-6 border-b border-zinc-900 flex items-center justify-between bg-zinc-950/50">
                <div className="flex items-center gap-2 text-orange-500">
                  <BookOpen className="w-5 h-5" />
                  <h3 className="font-bold uppercase tracking-wider text-xs">Tàng Kinh Các</h3>
                </div>
                <button 
                  onClick={() => setShowMobileLibrary(false)}
                  className="p-2 hover:bg-zinc-900 rounded-lg text-zinc-500 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-6 custom-scrollbar flex flex-col gap-4">
                <p className="text-xs text-zinc-400 mb-2">Tra cứu thông tin về linh dược, thảo mộc, công pháp, hoặc các khái niệm trong thế giới tu tiên.</p>
                
                <form onSubmit={handleLibrarySearch} className="flex gap-2">
                  <input
                    type="text"
                    value={libraryQuery}
                    onChange={(e) => setLibraryQuery(e.target.value)}
                    placeholder="Ví dụ: Linh khí đan..."
                    className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-orange-500/50"
                    disabled={isLibraryLoading}
                  />
                  <button
                    type="submit"
                    disabled={isLibraryLoading || !libraryQuery.trim()}
                    className="bg-orange-600 hover:bg-orange-500 text-white p-2 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    {isLibraryLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  </button>
                </form>

                {libraryResponse && (
                  <div className="mt-4 bg-zinc-900/50 border border-zinc-800 rounded-xl p-4 relative">
                    <button 
                      onClick={() => setLibraryResponse(null)}
                      className="absolute top-2 right-2 p-1 text-zinc-500 hover:text-white bg-zinc-800 rounded-md"
                    >
                      <X className="w-3 h-3" />
                    </button>
                    <div className="prose prose-invert prose-sm max-w-none markdown-body mt-2">
                      <Markdown>{libraryResponse}</Markdown>
                    </div>
                  </div>
                )}

                {!libraryResponse && (
                  <div className="mt-4">
                    {!libraryIndex ? (
                      <button
                        onClick={handleGenerateLibraryIndex}
                        disabled={isGeneratingIndex}
                        className="w-full py-3 bg-zinc-900 border border-zinc-800 hover:border-orange-500/50 rounded-xl text-sm text-zinc-300 hover:text-orange-500 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        {isGeneratingIndex ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            Đang sắp xếp...
                          </>
                        ) : (
                          <>
                            <BookOpen className="w-4 h-4" />
                            Khám phá Tàng Kinh Các
                          </>
                        )}
                      </button>
                    ) : (
                      <div className="space-y-6">
                        {libraryIndex.map((category, idx) => (
                          <div key={idx} className="space-y-3">
                            <h4 className="text-sm font-bold text-orange-500 border-b border-zinc-800 pb-1">{category.category}</h4>
                            <div className="space-y-4 pl-2">
                              {category.subcategories.map((sub, subIdx) => (
                                <div key={subIdx} className="space-y-2">
                                  <h5 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">{sub.name}</h5>
                                  <div className="grid grid-cols-1 gap-2">
                                    {sub.items.map((item, itemIdx) => (
                                      <button
                                        key={itemIdx}
                                        onClick={() => {
                                          setLibraryQuery(item.name);
                                          handleLibrarySearch({ preventDefault: () => {} } as React.FormEvent);
                                        }}
                                        className="text-left p-2 rounded-lg bg-zinc-900/50 border border-zinc-800 hover:border-orange-500/50 hover:bg-orange-500/10 transition-all group"
                                      >
                                        <div className="text-sm font-medium text-zinc-200 group-hover:text-orange-400">{item.name}</div>
                                        <div className="text-xs text-zinc-500 line-clamp-1">{item.shortDescription}</div>
                                      </button>
                                    ))}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMobileLibrary(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm -z-10"
            />
          </div>
        )}
      </AnimatePresence>

      {/* Map Modal */}
      <AnimatePresence>
        {showMapModal && mapImage && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setShowMapModal(false)}>
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative max-w-4xl w-full bg-zinc-900 p-2 rounded-2xl border border-zinc-800 shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <button 
                onClick={() => setShowMapModal(false)}
                className="absolute top-4 right-4 p-2 bg-black/50 hover:bg-black/80 rounded-full text-white transition-colors z-10"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="relative aspect-square md:aspect-video w-full overflow-hidden rounded-xl bg-zinc-950">
                <img src={mapImage} alt="Map" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
              </div>
              <div className="p-4 text-center">
                <h3 className="text-lg font-bold text-zinc-200">{currentResponse?.state.World_Variables.Current_Location}</h3>
                <p className="text-sm text-zinc-500 mt-1">Bản đồ khu vực hiện tại</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Chapter Viewer Modal */}
      <AnimatePresence>
        {viewingChapter && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md" onClick={() => setViewingChapter(null)}>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="relative max-w-2xl w-full max-h-[80vh] bg-zinc-900 border border-zinc-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-6 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/50">
                <div>
                  <span className="text-[10px] font-mono text-orange-500 uppercase tracking-widest">Hồi ức hành trình</span>
                  <h3 className="text-lg font-bold text-white mt-1">{viewingChapter.title}</h3>
                </div>
                <button 
                  onClick={() => setViewingChapter(null)}
                  className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-8 custom-scrollbar markdown-body">
                <Markdown>{viewingChapter.story}</Markdown>
              </div>
              {viewingChapter.state && (
                <div className="p-4 bg-zinc-950/50 border-t border-zinc-800 flex flex-col gap-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <span className="text-[8px] font-mono text-zinc-600 uppercase block">HP</span>
                      <span className="text-xs text-red-400">
                        {viewingChapter.state.MC_Status.HP_Current !== undefined ? `${viewingChapter.state.MC_Status.HP_Current}/${viewingChapter.state.MC_Status.HP_Max}` : viewingChapter.state.MC_Status.HP}
                      </span>
                    </div>
                    <div className="text-center">
                      <span className="text-[8px] font-mono text-zinc-600 uppercase block">Cảnh Giới</span>
                      <span className="text-xs text-blue-400">{viewingChapter.state.MC_Status.Level}</span>
                    </div>
                    <div className="text-center">
                      <span className="text-[8px] font-mono text-zinc-600 uppercase block">Vị Trí</span>
                      <span className="text-xs text-zinc-400 truncate block">{viewingChapter.state.World_Variables.Current_Location}</span>
                    </div>
                  </div>
                  {viewingChapter.id < chapters.length - 1 && (
                    <button
                      onClick={() => handleBranchFromChapter(viewingChapter.id)}
                      className="w-full py-3 bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/30 rounded-xl text-orange-500 text-xs font-bold tracking-widest uppercase transition-colors flex items-center justify-center gap-2"
                    >
                      <RotateCcw className="w-4 h-4" />
                      Tạo nhánh từ hồi này
                    </button>
                  )}
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
