import JSZip from 'jszip';

const extractTextFromHtml = (html: string) => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  return doc.body.textContent || '';
};

export const parseEpubFile = async (arrayBuffer: ArrayBuffer, onProgress?: (msg: string) => void): Promise<string> => {
  if (onProgress) onProgress('Đang giải nén tệp EPUB...');
  const zip = new JSZip();
  const loadedZip = await zip.loadAsync(arrayBuffer);

  // 1. Find OPF file from META-INF/container.xml
  if (onProgress) onProgress('Đang đọc cấu trúc truyện...');
  const containerXmlFile = loadedZip.file('META-INF/container.xml');
  if (!containerXmlFile) throw new Error('Invalid EPUB: Missing META-INF/container.xml');
  
  const containerXml = await containerXmlFile.async('string');
  const parser = new DOMParser();
  const containerDoc = parser.parseFromString(containerXml, 'text/xml');
  const rootfile = containerDoc.querySelector('rootfile');
  if (!rootfile) throw new Error('Invalid EPUB: No rootfile found in container.xml');
  
  const opfPath = rootfile.getAttribute('full-path');
  if (!opfPath) throw new Error('Invalid EPUB: rootfile missing full-path');
  
  // 2. Read OPF file
  const opfFile = loadedZip.file(opfPath);
  if (!opfFile) throw new Error(`Invalid EPUB: OPF file not found at ${opfPath}`);
  
  const opfXml = await opfFile.async('string');
  const opfDoc = parser.parseFromString(opfXml, 'text/xml');
  
  // 3. Parse Manifest and Spine
  const manifestItems = opfDoc.querySelectorAll('manifest > item');
  const itemMap: Record<string, string> = {};
  manifestItems.forEach(item => {
    const id = item.getAttribute('id');
    const href = item.getAttribute('href');
    if (id && href) itemMap[id] = href;
  });
  
  const spineItems = opfDoc.querySelectorAll('spine > itemref');
  const orderedPaths: string[] = [];
  
  // Resolve paths relative to OPF file
  const opfDir = opfPath.substring(0, opfPath.lastIndexOf('/') + 1);
  
  spineItems.forEach(itemref => {
    const idref = itemref.getAttribute('idref');
    if (idref && itemMap[idref]) {
      const href = decodeURIComponent(itemMap[idref]);
      orderedPaths.push(opfDir + href);
    }
  });
  
  // 4. Extract text from ordered HTML files
  let startText = '';
  let middleText = '';
  let endText = '';
  
  const MAX_START_CHARS = 400000;
  const MAX_MIDDLE_CHARS = 400000;
  const MAX_END_CHARS = 200000;
  
  // 4.1 Extract Start
  if (onProgress) onProgress('Đang trích xuất phần đầu truyện...');
  let startIndex = 0;
  for (; startIndex < orderedPaths.length; startIndex++) {
    const path = orderedPaths[startIndex];
    const file = loadedZip.file(path);
    if (file) {
      const html = await file.async('string');
      const text = extractTextFromHtml(html);
      const cleanedText = text.replace(/\s+/g, ' ').trim();
      if (cleanedText.length > 50) {
        startText += cleanedText + '\n\n';
      }
    }
    if (startText.length >= MAX_START_CHARS) break;
  }
  
  // 4.2 Extract End
  if (onProgress) onProgress('Đang trích xuất phần kết thúc...');
  let endIndex = orderedPaths.length - 1;
  let tempEndChunks: string[] = [];
  let currentEndChars = 0;
  for (; endIndex > startIndex; endIndex--) {
    const path = orderedPaths[endIndex];
    const file = loadedZip.file(path);
    if (file) {
      const html = await file.async('string');
      const text = extractTextFromHtml(html);
      const cleanedText = text.replace(/\s+/g, ' ').trim();
      if (cleanedText.length > 50) {
        tempEndChunks.unshift(cleanedText);
        currentEndChars += cleanedText.length;
      }
    }
    if (currentEndChars >= MAX_END_CHARS) break;
  }
  endText = tempEndChunks.join('\n\n');
  
  // 4.3 Extract Middle
  if (onProgress) onProgress('Đang trích xuất phần giữa truyện...');
  if (endIndex > startIndex + 1) {
    const midPoint = Math.floor((startIndex + endIndex) / 2);
    let currentMidChars = 0;
    let tempMidChunks: string[] = [];
    
    // Extract around midpoint
    let offset = 0;
    while (currentMidChars < MAX_MIDDLE_CHARS) {
      const idx1 = midPoint + offset;
      const idx2 = midPoint - offset - 1;
      let added = false;
      
      if (idx1 < endIndex && idx1 > startIndex) {
        const file = loadedZip.file(orderedPaths[idx1]);
        if (file) {
          const html = await file.async('string');
          const text = extractTextFromHtml(html);
          const cleanedText = text.replace(/\s+/g, ' ').trim();
          if (cleanedText.length > 50) {
            tempMidChunks.push(cleanedText);
            currentMidChars += cleanedText.length;
            added = true;
          }
        }
      }
      
      if (currentMidChars < MAX_MIDDLE_CHARS && idx2 > startIndex && idx2 < endIndex && idx2 !== idx1) {
        const file = loadedZip.file(orderedPaths[idx2]);
        if (file) {
          const html = await file.async('string');
          const text = extractTextFromHtml(html);
          const cleanedText = text.replace(/\s+/g, ' ').trim();
          if (cleanedText.length > 50) {
            tempMidChunks.unshift(cleanedText);
            currentMidChars += cleanedText.length;
            added = true;
          }
        }
      }
      
      offset++;
      if (!added && (midPoint + offset >= endIndex && midPoint - offset - 1 <= startIndex)) break;
    }
    middleText = tempMidChunks.join('\n\n');
  }
  
  let fullText = `[PHẦN ĐẦU TRUYỆN:]\n\n${startText}`;
  
  if (middleText) {
    fullText += `\n\n[... ĐOẠN TRÍCH GIỮA TRUYỆN ...]\n\n${middleText}`;
  }
  
  if (endText) {
    fullText += `\n\n[PHẦN KẾT THÚC CỦA TRUYỆN (Dùng để xác định điểm kết thúc, cảnh giới tối cao, trùm cuối của thế giới):]\n\n${endText}`;
  }
  
  return fullText;
};
